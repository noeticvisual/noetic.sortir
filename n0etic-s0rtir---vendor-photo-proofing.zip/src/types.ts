export type ProjectStatus = 
  | 'pending_upload'     // Menunggu upload foto dari fotografer
  | 'waiting_selection'  // Link sudah dikirim, menunggu klien memilih
  | 'submitted'          // Klien sudah submit pilihan final, siap diedit
  | 'completed';         // Fotografer sudah selesai mengedit & mengirim hasil

export type PhotoCategory = 'all' | 'ceremony' | 'reception' | 'portrait' | 'candid' | 'family';

export interface PhotoItem {
  id: string;
  projectId: string;
  fileName: string;
  originalUrl: string;
  previewUrl: string;     // URL or canvas data with watermark
  thumbnailUrl: string;
  fileSize: number;       // in bytes
  width?: number;
  height?: number;
  uploadedAt: string;
  category?: PhotoCategory;
  isSelected: boolean;    // Chosen for editing
  isFavorite: boolean;    // Marked as favorite/like
  clientNote?: string;    // Special retouch note e.g. "Tolong hilangkan orang di background"
  selectedAt?: string;
  isEdited?: boolean;     // Photographed marked as finished editing
}

export interface WatermarkConfig {
  text: string;
  opacity: number;        // 0.1 - 1.0
  position: 'diagonal' | 'center' | 'bottom-right' | 'tile';
  fontSize: number;       // e.g. 24
  color: string;          // e.g. '#ffffff'
  showVendorLogo?: boolean;
}

export interface ActivityLog {
  id: string;
  projectId: string;
  action: string;
  description: string;
  timestamp: string;
  actor: 'admin' | 'client';
}

export interface Project {
  id: string;
  title: string;
  clientName: string;
  clientEmail?: string;
  clientPhone?: string;
  sessionType: 'wedding' | 'prewedding' | 'engagement' | 'birthday' | 'graduation' | 'maternity' | 'portrait' | 'event';
  sessionDate: string;
  createdAt: string;
  status: ProjectStatus;
  
  // Selection quotas & rules
  allowedSelections: number; // e.g. 20 foto
  currentSelectionsCount: number;
  
  // Access & Security
  shareToken: string;        // UUID/unique string for link
  requiresPin: boolean;
  pinCode?: string;          // 4-6 digit access pin
  expiresAt?: string;        // ISO Date or undefined
  disableRightClick: boolean;
  watermark: WatermarkConfig;

  // Metadata
  coverPhotoUrl?: string;
  submittedAt?: string;
  finalClientNotes?: string;
  completedAt?: string;
}

export interface VendorProfile {
  name: string;
  tagline: string;
  email: string;
  phone: string;
  website: string;
  defaultWatermark: WatermarkConfig;
  defaultQuota: number;
  storageUsedBytes: number;
  storageMaxBytes: number;
}

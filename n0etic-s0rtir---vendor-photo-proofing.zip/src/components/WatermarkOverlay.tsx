import React from 'react';
import { WatermarkConfig } from '../types';

interface WatermarkOverlayProps {
  config: WatermarkConfig;
  vendorName?: string;
}

export const WatermarkOverlay: React.FC<WatermarkOverlayProps> = ({
  config,
  vendorName = 'LUMINA STORY',
}) => {
  const text = config.text || `${vendorName} • PROOF ONLY`;
  const opacity = config.opacity ?? 0.45;

  if (config.position === 'tile') {
    // Repeat tiled diagonal pattern across the entire image
    return (
      <div
        className="absolute inset-0 pointer-events-none select-none overflow-hidden z-20 flex flex-wrap items-center justify-center content-around p-4"
        style={{ opacity }}
      >
        {Array.from({ length: 9 }).map((_, i) => (
          <div
            key={i}
            className="w-1/3 h-1/3 flex items-center justify-center p-2 transform -rotate-25"
          >
            <div className="text-center font-bold tracking-widest uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)] border border-white/20 px-2 py-1 rounded bg-black/20 text-white text-[11px] sm:text-xs">
              {text}
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (config.position === 'diagonal') {
    return (
      <div
        className="absolute inset-0 pointer-events-none select-none flex items-center justify-center z-20 p-4"
        style={{ opacity }}
      >
        <div className="transform -rotate-30 text-center">
          <div className="text-white font-extrabold tracking-widest text-lg sm:text-2xl md:text-3xl uppercase drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] border-2 border-white/30 px-6 py-2 rounded-lg bg-black/25">
            {text}
          </div>
          <div className="text-white/80 text-[10px] sm:text-xs tracking-wider mt-1 drop-shadow">
            DO NOT SCREENSHOT • PROOF WATERMARK
          </div>
        </div>
      </div>
    );
  }

  if (config.position === 'center') {
    return (
      <div
        className="absolute inset-0 pointer-events-none select-none flex items-center justify-center z-20 p-4"
        style={{ opacity }}
      >
        <div className="bg-black/40 backdrop-blur-[2px] border border-white/30 px-4 py-2 rounded-md text-center">
          <p className="text-white font-bold tracking-widest text-sm sm:text-base uppercase drop-shadow">
            {text}
          </p>
        </div>
      </div>
    );
  }

  // bottom-right
  return (
    <div
      className="absolute bottom-3 right-3 pointer-events-none select-none z-20"
      style={{ opacity }}
    >
      <div className="bg-black/60 border border-white/20 px-3 py-1 rounded text-white text-xs font-semibold tracking-wider drop-shadow">
        {text}
      </div>
    </div>
  );
};

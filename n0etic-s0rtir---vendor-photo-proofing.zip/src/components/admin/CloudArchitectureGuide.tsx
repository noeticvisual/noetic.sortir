import React, { useState } from 'react';
import { 
  Cloud, Database, Server, ShieldCheck, DollarSign, 
  Layers, Check, Copy, ExternalLink, HelpCircle 
} from 'lucide-react';

export const CloudArchitectureGuide: React.FC = () => {
  const [projectCount, setProjectCount] = useState(12);
  const [avgPhotosPerProject, setAvgPhotosPerProject] = useState(300);
  const [copiedSql, setCopiedSql] = useState(false);

  // Storage math
  const avgFileSizeMB = 12; // 12 MB per RAW/High-Res JPG
  const totalStorageGB = Math.round((projectCount * avgPhotosPerProject * avgFileSizeMB) / 1024);

  // Estimated costs
  const awsCost = (totalStorageGB * 0.023 + totalStorageGB * 0.09).toFixed(2); // with egress
  const r2Cost = (totalStorageGB * 0.015).toFixed(2); // $0 egress
  const supabaseCost = totalStorageGB <= 1 ? 'Gratis (Free Tier)' : `$25 / bulan (Pro Plan s/d 100GB)`;

  const sqlSchema = `-- Skema Database PostgreSQL / Supabase untuk Website Sortir Foto

-- 1. Tabel Projects
CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  client_name TEXT NOT NULL,
  client_email TEXT,
  client_phone TEXT,
  session_type TEXT NOT NULL,
  session_date DATE NOT NULL,
  status TEXT DEFAULT 'pending_upload', -- pending_upload, waiting_selection, submitted, completed
  allowed_selections INT DEFAULT 20,
  share_token TEXT UNIQUE NOT NULL,
  requires_pin BOOLEAN DEFAULT true,
  pin_code TEXT,
  expires_at TIMESTAMP WITH TIME ZONE,
  watermark_text TEXT DEFAULT 'PROOF ONLY',
  final_client_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Tabel Photos
CREATE TABLE photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  file_name TEXT NOT NULL,
  original_storage_path TEXT NOT NULL,  -- Bucket path (tanpa watermark, hanya admin)
  preview_watermarked_url TEXT NOT NULL, -- URL ber-watermark untuk klien
  thumbnail_url TEXT NOT NULL,
  file_size BIGINT,
  category TEXT DEFAULT 'portrait',
  is_selected BOOLEAN DEFAULT false,
  is_favorite BOOLEAN DEFAULT false,
  client_note TEXT,
  selected_at TIMESTAMP WITH TIME ZONE,
  is_edited BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Row Level Security (RLS)
-- Klien hanya dapat membaca foto yang project_id-nya sesuai dengan share_token aktif
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
`;

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlSchema);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Recommendation */}
      <div className="bg-gradient-to-r from-amber-500/10 via-[#0e0f14] to-[#0e0f14] border border-amber-500/20 rounded-3xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-500/20">
            <Cloud className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
              Rekomendasi Teknis Vendor
            </span>
            <h2 className="text-xl font-bold text-white font-display">
              Arsitektur Cloud Storage & Database Termurah & Paling Efisien
            </h2>
          </div>
        </div>
        <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed max-w-4xl">
          Sebagai vendor fotografi, tantangan terbesar adalah <strong>biaya bandwidth (egress)</strong> dan <strong>kecepatan akses galeri klien</strong>. Berikut panduan arsitektur terbaik untuk skala vendor kecil hingga menengah.
        </p>
      </div>

      {/* Storage Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Recommendation 1: Cloudflare R2 */}
        <div className="bg-[#0e0f14] border-2 border-emerald-500/40 rounded-3xl p-5 flex flex-col justify-between relative shadow-xl">
          <div className="absolute -top-3 right-4 bg-emerald-400 text-neutral-950 font-bold text-[10px] uppercase tracking-wider px-2.5 py-0.5 rounded-full shadow">
            Juara 1: Biaya Paling Hemat
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-500/15 text-emerald-400 rounded-xl border border-emerald-500/20">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-display">Cloudflare R2</h3>
                <span className="text-[11px] text-emerald-400 font-semibold">S3-Compatible Object Storage</span>
              </div>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Pilihan terbaik untuk foto beresolusi tinggi karena <strong>$0 Biaya Egress (Bandwidth Gratis)</strong>. Klien bebas membuka ratusan foto tanpa vendor ditagih biaya transfer data.
            </p>
            <ul className="text-xs text-neutral-300 space-y-1.5 pt-2">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Biaya penyimpanan: ~$0.015 / GB per bulan</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Gratis 10 GB pertama tiap bulan</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Mendukung upload multipart langsung dari browser</span>
              </li>
            </ul>
          </div>
          <div className="mt-4 pt-3 border-t border-neutral-800/80 text-xs font-mono text-emerald-400 font-bold">
            Estimasi: ~Rp 25.000 / 100 GB
          </div>
        </div>

        {/* Recommendation 2: Supabase */}
        <div className="bg-[#0e0f14] border border-neutral-800/80 rounded-3xl p-5 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-500/20">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-display">Supabase (Database + Storage)</h3>
                <span className="text-[11px] text-amber-400 font-semibold">PostgreSQL & Auth Terpadu</span>
              </div>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Satu platform untuk semua kebutuhan: database project, link token, row-level security (RLS), dan media storage tanpa ribet setup server backend.
            </p>
            <ul className="text-xs text-neutral-300 space-y-1.5 pt-2">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Free tier: 500 MB Database + 1 GB Storage</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Pro Plan ($25/bln): kuota 100 GB storage</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Instant REST / GraphQL API & Real-time update</span>
              </li>
            </ul>
          </div>
          <div className="mt-4 pt-3 border-t border-neutral-800/80 text-xs font-mono text-amber-400 font-bold">
            All-in-One Developer Friendly
          </div>
        </div>

        {/* Recommendation 3: Cloudinary */}
        <div className="bg-[#0e0f14] border border-neutral-800/80 rounded-3xl p-5 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-sky-500/15 text-sky-400 rounded-xl border border-sky-500/20">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-display">Cloudinary</h3>
                <span className="text-[11px] text-sky-400 font-semibold">Smart Watermark & CDN</span>
              </div>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Sangat praktis untuk menerapkan watermark dinamis secara otomatis melalui URL parameter (misal: teks nama studio atau logo) tanpa memproses ulang gambar di server.
            </p>
            <ul className="text-xs text-neutral-300 space-y-1.5 pt-2">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span>Otomatis ubah resolusi ke thumbnail mobile (w_400,q_auto)</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span>Dynamic text overlay watermark via URL</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span>Free Plan: 25 kredit / bulan (~25.000 transformasi)</span>
              </li>
            </ul>
          </div>
          <div className="mt-4 pt-3 border-t border-neutral-800/80 text-xs font-mono text-sky-400 font-bold">
            Terbaik untuk Watermark Otomatis
          </div>
        </div>
      </div>

      {/* Interactive Storage & Cost Calculator */}
      <div className="bg-[#0e0f14] border border-neutral-800/80 rounded-3xl p-6">
        <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2 font-display">
          <DollarSign className="w-5 h-5 text-amber-400 stroke-[2.2]" />
          <span>Kalkulator Estimasi Kebutuhan Storage Vendor Anda</span>
        </h3>
        <p className="text-xs text-neutral-400 mb-6">
          Hitung estimasi kapasitas penyimpanan dan perbandingan biaya per bulan berdasarkan volume pemotretan Anda:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-neutral-300">Jumlah Project per Bulan:</span>
                <span className="text-amber-400 font-mono font-bold">{projectCount} Project</span>
              </div>
              <input
                type="range"
                min={2}
                max={50}
                value={projectCount}
                onChange={(e) => setProjectCount(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-neutral-300">Rata-rata Foto per Sesi:</span>
                <span className="text-amber-400 font-mono font-bold">{avgPhotosPerProject} Foto</span>
              </div>
              <input
                type="range"
                min={100}
                max={1500}
                step={50}
                value={avgPhotosPerProject}
                onChange={(e) => setAvgPhotosPerProject(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          </div>

          <div className="bg-[#07080a] p-4 rounded-2xl border border-neutral-800 space-y-2.5 text-xs">
            <div className="flex justify-between">
              <span className="text-neutral-400">Total File per Bulan:</span>
              <span className="font-mono text-white font-bold">{(projectCount * avgPhotosPerProject).toLocaleString('id-ID')} Foto</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Kapasitas Storage Dibutuhkan:</span>
              <span className="font-mono text-amber-400 font-bold">{totalStorageGB} GB / bulan</span>
            </div>
            <div className="border-t border-neutral-800 pt-2 flex justify-between items-baseline">
              <span className="text-neutral-400">Estimasi Cloudflare R2:</span>
              <span className="font-mono text-emerald-400 font-bold">${r2Cost} (~Rp {Math.round(Number(r2Cost) * 16000).toLocaleString('id-ID')})</span>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-neutral-400">Estimasi AWS S3 (Termasuk Egress):</span>
              <span className="font-mono text-rose-400 font-bold">${awsCost} (~Rp {Math.round(Number(awsCost) * 16000).toLocaleString('id-ID')})</span>
            </div>
            <p className="text-[11px] text-neutral-500 pt-1">
              * Terlihat jelas: Cloudflare R2 menghemat hingga 80% biaya karena tidak mengenakan biaya transfer data saat klien membuka galeri!
            </p>
          </div>
        </div>
      </div>

      {/* SQL Migration Script Box */}
      <div className="bg-[#0e0f14] border border-neutral-800/80 rounded-3xl p-6 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white font-display">Struktur Skema Database PostgreSQL / Supabase</h3>
            <p className="text-xs text-neutral-400">Dapat langsung dieksekusi di Supabase SQL Editor</p>
          </div>
          <button
            type="button"
            onClick={handleCopySql}
            className="px-3.5 py-1.5 bg-[#14151c] hover:bg-[#1e202c] text-neutral-200 border border-neutral-700/60 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
          >
            {copiedSql ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
            <span>{copiedSql ? 'Tersalin' : 'Salin SQL'}</span>
          </button>
        </div>

        <div className="bg-[#07080a] p-4 rounded-2xl border border-neutral-800 overflow-x-auto max-h-64 font-mono text-xs text-neutral-300 leading-relaxed">
          <pre>{sqlSchema}</pre>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Project, VendorProfile } from '../../types';
import { 
  X, Copy, Check, Share2, MessageCircle, 
  Lock, Calendar, ExternalLink, ShieldAlert 
} from 'lucide-react';

interface ShareLinkModalProps {
  isOpen: boolean;
  project: Project;
  vendor: VendorProfile;
  onClose: () => void;
  onOpenClientView: () => void;
}

export const ShareLinkModal: React.FC<ShareLinkModalProps> = ({
  isOpen,
  project,
  vendor,
  onClose,
  onOpenClientView,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Construct client URL
  const origin = window.location.origin + window.location.pathname;
  const shareUrl = `${origin}?project=${project.shareToken}`;

  const messageText = 
`Halo Kak ${project.clientName},

Berikut adalah link galeri foto sesi *${project.title}* Anda untuk sortir dan memilih *${project.allowedSelections} foto* yang ingin diedit profesional:

🔗 ${shareUrl}
${project.requiresPin ? `🔑 PIN Akses: *${project.pinCode}*` : ''}
${project.expiresAt ? `⏳ Berlaku hingga: ${project.expiresAt}` : ''}

Silakan buka link tersebut, beri tanda centang pada foto favorit, lalu klik *Submit Pilihan Final*.

Terima kasih,
*${vendor.name}*`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyFullMessage = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsApp = () => {
    const cleanPhone = (project.clientPhone || '').replace(/[^0-9]/g, '');
    const encoded = encodeURIComponent(messageText);
    if (cleanPhone) {
      window.open(`https://wa.me/${cleanPhone}?text=${encoded}`, '_blank');
    } else {
      window.open(`https://wa.me/?text=${encoded}`, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0e0f14] border border-neutral-800/90 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-500/20">
              <Share2 className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display">Bagikan Galeri ke Klien</h2>
              <p className="text-xs text-neutral-400">{project.clientName} • {project.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-xl hover:bg-neutral-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {/* Direct URL Box */}
          <div>
            <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider block mb-1.5">
              Link Khusus Sesi (Hanya Akses Klien)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 bg-[#07080a] border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-amber-300 font-mono focus:outline-none select-all"
              />
              <button
                type="button"
                onClick={handleCopyLink}
                className="bg-[#14151c] hover:bg-[#1c1d28] border border-neutral-700/60 text-neutral-200 px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
                <span>{copied ? 'Tersalin' : 'Salin'}</span>
              </button>
            </div>
          </div>

          {/* Access Security Info */}
          <div className="grid grid-cols-2 gap-3 p-3.5 bg-[#12131a] rounded-2xl border border-neutral-800/80 text-xs">
            <div>
              <span className="text-neutral-500 block text-[11px] font-medium">Proteksi PIN:</span>
              <span className="font-mono text-white font-bold flex items-center gap-1 mt-0.5">
                {project.requiresPin ? (
                  <>
                    <Lock className="w-3.5 h-3.5 text-amber-400 stroke-[2.2]" />
                    <span className="text-amber-400">{project.pinCode || 'Aktif'}</span>
                  </>
                ) : (
                  <span className="text-neutral-400">Tanpa PIN (Langsung Terbuka)</span>
                )}
              </span>
            </div>
            <div>
              <span className="text-neutral-500 block text-[11px] font-medium">Masa Berlaku:</span>
              <span className="text-neutral-300 font-medium flex items-center gap-1 mt-0.5">
                <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                <span>{project.expiresAt || 'Selamanya (Aktif)'}</span>
              </span>
            </div>
          </div>

          {/* WhatsApp Template Preview */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                Format Pesan WhatsApp Siap Kirim
              </label>
              <button
                type="button"
                onClick={handleCopyFullMessage}
                className="text-[11px] text-amber-400 hover:text-amber-300 hover:underline font-medium"
              >
                Salin Seluruh Pesan
              </button>
            </div>
            <div className="bg-[#07080a] border border-neutral-800 rounded-2xl p-3 text-xs text-neutral-300 font-sans whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed border-l-4 border-l-emerald-500">
              {messageText}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-1">
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="w-full bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/15 transition-all active:scale-95 text-xs sm:text-sm"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Kirim Langsung ke WhatsApp Klien</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenClientView();
              }}
              className="w-full bg-[#14151c] hover:bg-[#1a1c26] border border-neutral-800 text-neutral-300 font-medium py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors text-xs"
            >
              <ExternalLink className="w-4 h-4 text-amber-400" />
              <span>Buka Tampilan Klien (Uji Coba Seleksi)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

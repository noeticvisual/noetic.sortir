import React, { useState, useRef } from 'react';
import { Project, PhotoCategory, PhotoItem } from '../../types';
import { 
  X, UploadCloud, Image as ImageIcon, Trash2, CheckCircle2, 
  Sparkles, Layers, ShieldCheck 
} from 'lucide-react';

interface PhotoUploadModalProps {
  isOpen: boolean;
  project: Project;
  onClose: () => void;
  onUploadComplete: (newPhotos: Omit<PhotoItem, 'id' | 'projectId' | 'uploadedAt' | 'isSelected' | 'isFavorite'>[]) => void;
}

interface StagedFile {
  name: string;
  size: number;
  previewUrl: string;
  category: PhotoCategory;
}

export const PhotoUploadModal: React.FC<PhotoUploadModalProps> = ({
  isOpen,
  project,
  onClose,
  onUploadComplete,
}) => {
  const [stagedFiles, setStagedFiles] = useState<StagedFile[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<PhotoCategory>('portrait');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFiles = (files: FileList | File[]) => {
    const list = Array.from(files);
    const newStaged: StagedFile[] = [];

    list.forEach((file) => {
      if (file.type.startsWith('image/')) {
        const objectUrl = URL.createObjectURL(file);
        newStaged.push({
          name: file.name,
          size: file.size,
          previewUrl: objectUrl,
          category: selectedCategory,
        });
      }
    });

    setStagedFiles((prev) => [...prev, ...newStaged]);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleRemoveStaged = (index: number) => {
    setStagedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  // Quick Preset Sample Photos Generator for realistic testing
  const handleLoadSampleBatch = () => {
    const sampleStock = [
      {
        name: 'IMG_WED_0710.JPG',
        url: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1600&auto=format&fit=crop',
        category: 'portrait' as PhotoCategory,
        size: 14200000,
      },
      {
        name: 'IMG_WED_0724.JPG',
        url: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=1600&auto=format&fit=crop',
        category: 'ceremony' as PhotoCategory,
        size: 15300000,
      },
      {
        name: 'IMG_WED_0755.JPG',
        url: 'https://images.unsplash.com/photo-1544078751-58fee2d8a03b?q=80&w=1600&auto=format&fit=crop',
        category: 'candid' as PhotoCategory,
        size: 13800000,
      },
      {
        name: 'IMG_WED_0782.JPG',
        url: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=1600&auto=format&fit=crop',
        category: 'reception' as PhotoCategory,
        size: 14900000,
      },
      {
        name: 'IMG_WED_0810.JPG',
        url: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?q=80&w=1600&auto=format&fit=crop',
        category: 'family' as PhotoCategory,
        size: 16100000,
      },
    ];

    const mapped: StagedFile[] = sampleStock.map((s) => ({
      name: s.name,
      size: s.size,
      previewUrl: s.url,
      category: s.category,
    }));

    setStagedFiles((prev) => [...prev, ...mapped]);
  };

  const handleStartUpload = () => {
    if (stagedFiles.length === 0) return;

    setIsUploading(true);
    setUploadProgress(15);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 95) {
          clearInterval(interval);
          return 95;
        }
        return prev + 25;
      });
    }, 200);

    setTimeout(() => {
      clearInterval(interval);
      setUploadProgress(100);

      const readyPayload = stagedFiles.map((f) => ({
        fileName: f.name,
        originalUrl: f.previewUrl,
        previewUrl: f.previewUrl,
        thumbnailUrl: f.previewUrl,
        fileSize: f.size,
        category: f.category,
      }));

      onUploadComplete(readyPayload);
      setIsUploading(false);
      onClose();
    }, 1100);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0e0f14] border border-neutral-800/90 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-500/20">
              <UploadCloud className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display">Upload Foto Massal</h2>
              <p className="text-xs text-neutral-400">
                Project: {project.title} • Watermark otomatis aktif
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-xl hover:bg-neutral-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 text-xs overflow-y-auto max-h-[75vh]">
          {/* Default Category selector */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-[#12131a] rounded-2xl border border-neutral-800/80">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span className="font-semibold text-neutral-300">Kategori Batch Foto:</span>
            </div>
            <div className="flex items-center gap-1.5">
              {(['portrait', 'ceremony', 'reception', 'candid', 'family'] as PhotoCategory[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-xl capitalize transition-colors text-xs font-medium ${
                    selectedCategory === cat
                      ? 'bg-amber-400 text-neutral-950 font-bold'
                      : 'bg-[#07080a] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Drag & Drop Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-amber-500 bg-amber-500/10'
                : 'border-neutral-700/80 hover:border-neutral-500 bg-[#07080a]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/jpeg,image/png,image/webp,image/heic"
              onChange={(e) => e.target.files && handleFiles(e.target.files)}
              className="hidden"
            />
            <UploadCloud className="w-12 h-12 mx-auto text-amber-400 mb-2 stroke-[1.8]" />
            <h3 className="text-sm font-bold text-white mb-1">
              Drag & Drop file foto ke sini, atau klik untuk memilih file
            </h3>
            <p className="text-xs text-neutral-400 max-w-sm mx-auto">
              Mendukung banyak file sekaligus (JPG, PNG, WebP, HEIC). Resolusi kamera DSLR/Mirrorless didukung.
            </p>

            <div className="mt-4 flex items-center justify-center gap-2">
              <span className="text-[11px] text-neutral-500">atau</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleLoadSampleBatch();
                }}
                className="px-3 py-1.5 bg-[#14151c] hover:bg-[#1a1c26] text-amber-300 border border-neutral-700/60 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Isi dengan 5 Foto Sample Demo</span>
              </button>
            </div>
          </div>

          {/* Watermark Security Notice */}
          <div className="flex items-center gap-2 p-3 bg-[#12131a] rounded-2xl border border-neutral-800/80 text-neutral-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-[11px]">
              Sistem akan otomatis menghasilkan thumbnail ringan & menerapkan watermark{' '}
              <strong className="text-neutral-200">&ldquo;{project.watermark.text}&rdquo;</strong> pada versi yang dilihat klien.
            </span>
          </div>

          {/* Staged Files List */}
          {stagedFiles.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-neutral-300 uppercase tracking-wider text-[11px]">
                  Foto Siap Diunggah ({stagedFiles.length} file)
                </span>
                <button
                  type="button"
                  onClick={() => setStagedFiles([])}
                  className="text-rose-400 hover:underline text-[11px]"
                >
                  Kosongkan Semua
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-48 overflow-y-auto p-2 bg-[#07080a] rounded-2xl border border-neutral-800/80">
                {stagedFiles.map((file, idx) => (
                  <div
                    key={idx}
                    className="relative group rounded-xl overflow-hidden border border-neutral-800 aspect-[4/3] bg-[#0e0f14]"
                  >
                    <img
                      src={file.previewUrl}
                      alt={file.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveStaged(idx)}
                        className="p-1.5 bg-rose-600 rounded-full text-white hover:bg-rose-500"
                        title="Hapus file ini"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="absolute bottom-0 inset-x-0 p-1 bg-black/80 text-[10px] text-neutral-300 truncate font-mono">
                      {file.name}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload Progress Bar */}
          {isUploading && (
            <div className="space-y-1.5 p-3 bg-[#12131a] rounded-2xl border border-neutral-800/80">
              <div className="flex justify-between text-xs text-neutral-300 font-medium">
                <span>Mengompresi & Menerapkan Watermark...</span>
                <span className="font-mono text-amber-400 font-bold">{uploadProgress}%</span>
              </div>
              <div className="w-full bg-[#07080a] h-2 rounded-full overflow-hidden border border-neutral-800">
                <div
                  className="bg-gradient-to-r from-amber-500 to-amber-400 h-full transition-all duration-200"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-[#07080a] border-t border-neutral-800/80 flex items-center justify-between">
          <span className="text-xs text-neutral-500">
            Total: {stagedFiles.length} file dipilih
          </span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold rounded-xl transition-colors"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={stagedFiles.length === 0 || isUploading}
              onClick={handleStartUpload}
              className="px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 disabled:opacity-40 disabled:cursor-not-allowed text-neutral-950 text-xs font-bold rounded-xl shadow-lg shadow-amber-500/10 flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <UploadCloud className="w-4 h-4 stroke-[2.2]" />
              <span>
                {isUploading ? 'Sedang Mengunggah...' : `Unggah ${stagedFiles.length} Foto`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

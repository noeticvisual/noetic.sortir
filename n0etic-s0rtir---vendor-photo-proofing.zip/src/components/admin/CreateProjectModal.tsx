import React, { useState } from 'react';
import { Project } from '../../types';
import { X, Plus, Sparkles, Lock, Shield, Calendar, Image as ImageIcon } from 'lucide-react';

interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (data: {
    title: string;
    clientName: string;
    clientEmail?: string;
    clientPhone?: string;
    sessionType: Project['sessionType'];
    sessionDate: string;
    allowedSelections: number;
    requiresPin: boolean;
    pinCode?: string;
    expiresDays?: number;
    watermarkText?: string;
  }) => void;
}

export const CreateProjectModal: React.FC<CreateProjectModalProps> = ({
  isOpen,
  onClose,
  onCreate,
}) => {
  const [title, setTitle] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [sessionType, setSessionType] = useState<Project['sessionType']>('wedding');
  const [sessionDate, setSessionDate] = useState(new Date().toISOString().split('T')[0]);
  const [allowedSelections, setAllowedSelections] = useState(20);
  const [requiresPin, setRequiresPin] = useState(true);
  const [pinCode, setPinCode] = useState(() => Math.floor(1000 + Math.random() * 9000).toString());
  const [expiresDays, setExpiresDays] = useState<number | undefined>(14);
  const [watermarkText, setWatermarkText] = useState('n0etic s0rtir • PROOF ONLY');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !clientName.trim()) return;

    onCreate({
      title: title.trim(),
      clientName: clientName.trim(),
      clientEmail: clientEmail.trim() || undefined,
      clientPhone: clientPhone.trim() || undefined,
      sessionType,
      sessionDate,
      allowedSelections: Number(allowedSelections) || 20,
      requiresPin,
      pinCode: requiresPin ? pinCode : undefined,
      expiresDays,
      watermarkText: watermarkText.trim() || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0e0f14] border border-neutral-800/90 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-500/20">
              <Plus className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display">Buat Project Foto Baru</h2>
              <p className="text-xs text-neutral-400">Siapkan galeri seleksi khusus untuk klien Anda</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-xl hover:bg-neutral-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs overflow-y-auto max-h-[80vh]">
          {/* Project Title */}
          <div>
            <label className="block font-semibold text-neutral-300 uppercase tracking-wider mb-1">
              Judul Sesi Foto *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Contoh: The Wedding of Rama & Sesha"
              className="w-full bg-[#12131a] border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
            />
          </div>

          {/* Client Name & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Nama Klien *
              </label>
              <input
                type="text"
                required
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Contoh: Sesha Adiwijaya"
                className="w-full bg-[#12131a] border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                No. WhatsApp Klien
              </label>
              <input
                type="text"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                placeholder="081234567890"
                className="w-full bg-[#12131a] border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>
          </div>

          {/* Session Type & Session Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Jenis Sesi Foto
              </label>
              <select
                value={sessionType}
                onChange={(e) => setSessionType(e.target.value as Project['sessionType'])}
                className="w-full bg-[#12131a] border border-neutral-800 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 capitalize"
              >
                <option value="wedding">Wedding (Pernikahan)</option>
                <option value="prewedding">Prewedding</option>
                <option value="engagement">Engagement / Lamaran / Sangjit</option>
                <option value="birthday">Birthday / Sweet 17</option>
                <option value="graduation">Graduation / Wisuda</option>
                <option value="maternity">Maternity</option>
                <option value="portrait">Studio Portrait / Commercial</option>
                <option value="event">Corporate Event / Acara</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Tanggal Sesi Foto
              </label>
              <input
                type="date"
                value={sessionDate}
                onChange={(e) => setSessionDate(e.target.value)}
                className="w-full bg-[#12131a] border border-neutral-800 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Quota & Watermark */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Batas Foto Pilihan Klien (Kuota) *
              </label>
              <div className="relative">
                <input
                  type="number"
                  min={1}
                  max={200}
                  required
                  value={allowedSelections}
                  onChange={(e) => setAllowedSelections(parseInt(e.target.value) || 20)}
                  className="w-full bg-[#12131a] border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-amber-400 font-mono font-bold focus:outline-none focus:border-amber-500 transition-colors"
                />
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-500">
                  Foto Edit
                </span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">
                Klien tidak bisa memilih lebih dari kuota ini.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Masa Aktif Link Klien
              </label>
              <select
                value={expiresDays ?? ''}
                onChange={(e) => setExpiresDays(e.target.value ? Number(e.target.value) : undefined)}
                className="w-full bg-[#12131a] border border-neutral-800 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
              >
                <option value={7}>7 Hari</option>
                <option value={14}>14 Hari (Standar)</option>
                <option value={30}>30 Hari (1 Bulan)</option>
                <option value="">Tanpa Batas Kadaluarsa</option>
              </select>
            </div>
          </div>

          {/* Watermark Configuration */}
          <div className="p-3.5 bg-[#12131a] rounded-2xl border border-neutral-800/80 space-y-2">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400 stroke-[2.2]" />
              <label className="font-semibold text-neutral-200 uppercase tracking-wider">
                Watermark Otomatis Preview
              </label>
            </div>
            <input
              type="text"
              value={watermarkText}
              onChange={(e) => setWatermarkText(e.target.value)}
              placeholder="Teks watermark preview..."
              className="w-full bg-[#07080a] border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 transition-colors"
            />
            <p className="text-[11px] text-neutral-400">
              Watermark ini akan otomatis ditimpa ke foto yang dilihat klien agar foto mentah tidak dapat dicuri sebelum disetujui.
            </p>
          </div>

          {/* PIN Security Toggle */}
          <div className="p-3.5 bg-[#12131a] rounded-2xl border border-neutral-800/80 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 font-semibold text-neutral-200">
                <Lock className="w-4 h-4 text-amber-400 stroke-[2.2]" />
                <span>Proteksi PIN Akses Galeri</span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Klien wajib memasukkan PIN sebelum dapat melihat galeri.
              </p>
            </div>
            <div className="flex items-center gap-3">
              {requiresPin && (
                <input
                  type="text"
                  maxLength={6}
                  value={pinCode}
                  onChange={(e) => setPinCode(e.target.value)}
                  className="w-20 bg-[#07080a] border border-neutral-700 rounded-xl py-1.5 px-2 text-center font-mono font-bold text-amber-400 text-xs focus:outline-none focus:border-amber-500"
                />
              )}
              <input
                type="checkbox"
                checked={requiresPin}
                onChange={(e) => setRequiresPin(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="pt-3 flex justify-end gap-3 border-t border-neutral-800/80">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl font-medium transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-neutral-950 font-bold rounded-xl shadow-lg shadow-amber-500/10 flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <Sparkles className="w-4 h-4 stroke-[2.2]" />
              <span>Simpan & Buat Project</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

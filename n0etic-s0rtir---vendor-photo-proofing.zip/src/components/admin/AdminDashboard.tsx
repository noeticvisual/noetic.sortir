import React, { useState, useMemo } from 'react';
import { Project, PhotoItem, VendorProfile, ProjectStatus } from '../../types';
import { 
  Plus, Search, Filter, Share2, UploadCloud, Eye, 
  CheckCircle2, Clock, Image as ImageIcon, Sparkles, 
  Trash2, ExternalLink, HardDrive, Shield, Lock, 
  Calendar, Layers, ArrowRight, RefreshCw, BookOpen 
} from 'lucide-react';

interface AdminDashboardProps {
  projects: Project[];
  photos: PhotoItem[];
  vendor: VendorProfile;
  onSelectProjectForReview: (project: Project) => void;
  onOpenUploadModal: (project: Project) => void;
  onOpenShareModal: (project: Project) => void;
  onOpenCreateProjectModal: () => void;
  onOpenClientView: (project: Project) => void;
  onOpenCloudGuide: () => void;
  onDeleteProject: (projectId: string) => void;
  onResetDemoData: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  projects,
  photos,
  vendor,
  onSelectProjectForReview,
  onOpenUploadModal,
  onOpenShareModal,
  onOpenCreateProjectModal,
  onOpenClientView,
  onOpenCloudGuide,
  onDeleteProject,
  onResetDemoData,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | ProjectStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Status counts
  const counts = useMemo(() => {
    return {
      all: projects.length,
      pending_upload: projects.filter((p) => p.status === 'pending_upload').length,
      waiting_selection: projects.filter((p) => p.status === 'waiting_selection').length,
      submitted: projects.filter((p) => p.status === 'submitted').length,
      completed: projects.filter((p) => p.status === 'completed').length,
    };
  }, [projects]);

  // Filtered projects
  const filteredProjects = useMemo(() => {
    return projects.filter((p) => {
      if (activeTab !== 'all' && p.status !== activeTab) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = p.title.toLowerCase().includes(q);
        const matchClient = p.clientName.toLowerCase().includes(q);
        const matchPhone = p.clientPhone?.toLowerCase().includes(q);
        const matchType = p.sessionType.toLowerCase().includes(q);
        if (!matchTitle && !matchClient && !matchPhone && !matchType) return false;
      }
      return true;
    });
  }, [projects, activeTab, searchQuery]);

  // Helper for project photo count
  const getProjectPhotoCount = (projectId: string) => {
    return photos.filter((p) => p.projectId === projectId).length;
  };

  const getStatusBadge = (status: ProjectStatus) => {
    switch (status) {
      case 'pending_upload':
        return {
          label: 'Menunggu Upload',
          class: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
          icon: UploadCloud,
        };
      case 'waiting_selection':
        return {
          label: 'Menunggu Klien',
          class: 'bg-sky-500/15 text-sky-400 border-sky-500/30',
          icon: Clock,
        };
      case 'submitted':
        return {
          label: 'Siap Diedit (Disubmit)',
          class: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 font-bold',
          icon: CheckCircle2,
        };
      case 'completed':
        return {
          label: 'Selesai',
          class: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
          icon: Sparkles,
        };
    }
  };

  const storageUsedGB = (vendor.storageUsedBytes / (1024 * 1024 * 1024)).toFixed(1);
  const storageMaxGB = (vendor.storageMaxBytes / (1024 * 1024 * 1024)).toFixed(0);
  const storagePercent = Math.round((vendor.storageUsedBytes / vendor.storageMaxBytes) * 100);

  return (
    <div className="space-y-8 pb-12">
      {/* Top Welcome & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/25">
              Admin Vendor Portal
            </span>
            <span className="text-xs text-neutral-500">• {vendor.tagline}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-white mt-1.5 tracking-tight">
            Dashboard Sesi & Seleksi Foto
          </h1>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onOpenCloudGuide}
            className="px-3.5 py-2.5 bg-[#0e0f14] hover:bg-[#151720] text-neutral-300 border border-neutral-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span>Panduan Cloud & Storage</span>
          </button>

          <button
            type="button"
            onClick={onOpenCreateProjectModal}
            className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-neutral-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/10 flex items-center gap-1.5 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Buat Project Baru</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <div 
          onClick={() => setActiveTab('all')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'all' ? 'bg-[#14151e] border-amber-500/60 ring-1 ring-amber-500/20' : 'bg-[#0e0f14] border-neutral-800/80 hover:border-neutral-700'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
            <span>Total Project</span>
            <Layers className="w-4 h-4 text-neutral-500" />
          </div>
          <p className="text-2xl font-bold font-mono text-white">{counts.all}</p>
          <p className="text-[11px] text-neutral-500 mt-1">Semua Sesi Klien</p>
        </div>

        <div 
          onClick={() => setActiveTab('pending_upload')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'pending_upload' ? 'bg-[#14151e] border-amber-500/60 ring-1 ring-amber-500/20' : 'bg-[#0e0f14] border-neutral-800/80 hover:border-neutral-700'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
            <span>Menunggu Upload</span>
            <UploadCloud className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-amber-400">{counts.pending_upload}</p>
          <p className="text-[11px] text-neutral-500 mt-1">Belum Ada Foto</p>
        </div>

        <div 
          onClick={() => setActiveTab('waiting_selection')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'waiting_selection' ? 'bg-[#14151e] border-amber-500/60 ring-1 ring-amber-500/20' : 'bg-[#0e0f14] border-neutral-800/80 hover:border-neutral-700'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
            <span>Menunggu Klien</span>
            <Clock className="w-4 h-4 text-sky-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-sky-400">{counts.waiting_selection}</p>
          <p className="text-[11px] text-neutral-500 mt-1">Sedang Dipilih Klien</p>
        </div>

        <div 
          onClick={() => setActiveTab('submitted')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'submitted' ? 'bg-[#14151e] border-emerald-500/60 ring-1 ring-emerald-500/20' : 'bg-[#0e0f14] border-neutral-800/80 hover:border-neutral-700 ring-1 ring-emerald-500/10'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
            <span>Siap Diedit</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-400">{counts.submitted}</p>
          <p className="text-[11px] text-neutral-500 mt-1">Pilihan Final Diterima</p>
        </div>

        <div 
          onClick={() => setActiveTab('completed')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all col-span-2 lg:col-span-1 ${
            activeTab === 'completed' ? 'bg-[#14151e] border-purple-500/60 ring-1 ring-purple-500/20' : 'bg-[#0e0f14] border-neutral-800/80 hover:border-neutral-700'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
            <span>Selesai</span>
            <Sparkles className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-purple-400">{counts.completed}</p>
          <p className="text-[11px] text-neutral-500 mt-1">Selesai & Dikirim</p>
        </div>
      </div>

      {/* Storage Indicator Banner */}
      <div className="bg-[#0e0f14] border border-neutral-800/90 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="p-2.5 bg-[#14151c] text-amber-400 rounded-xl border border-neutral-800">
            <HardDrive className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-neutral-300">Penggunaan Cloud Storage</span>
              <span className="text-xs font-mono font-bold text-amber-400">
                {storageUsedGB} GB / {storageMaxGB} GB ({storagePercent}%)
              </span>
            </div>
            <p className="text-[11px] text-neutral-500">
              Optimal dengan kompresi thumbnail preview & watermark otomatis
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <div className="w-32 bg-[#14151c] h-2 rounded-full overflow-hidden border border-neutral-800/80 hidden md:block">
            <div className="bg-gradient-to-r from-amber-500 to-amber-400 h-full" style={{ width: `${storagePercent}%` }} />
          </div>
          <button
            onClick={onOpenCloudGuide}
            className="text-xs text-amber-400 hover:text-amber-300 hover:underline font-medium whitespace-nowrap transition-colors"
          >
            Pelajari Opsi Storage Murah &rarr;
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-1 sm:pb-0">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
              activeTab === 'all'
                ? 'bg-amber-400 text-neutral-950 font-bold shadow-md'
                : 'bg-[#0e0f14] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
            }`}
          >
            Semua ({counts.all})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('submitted')}
            className={`px-3.5 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
              activeTab === 'submitted'
                ? 'bg-emerald-400 text-neutral-950 font-bold shadow-md'
                : 'bg-[#0e0f14] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
            }`}
          >
            Siap Edit ({counts.submitted})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('waiting_selection')}
            className={`px-3.5 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
              activeTab === 'waiting_selection'
                ? 'bg-sky-400 text-neutral-950 font-bold shadow-md'
                : 'bg-[#0e0f14] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
            }`}
          >
            Menunggu Klien ({counts.waiting_selection})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('pending_upload')}
            className={`px-3.5 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
              activeTab === 'pending_upload'
                ? 'bg-amber-400 text-neutral-950 font-bold shadow-md'
                : 'bg-[#0e0f14] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
            }`}
          >
            Menunggu Upload ({counts.pending_upload})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('completed')}
            className={`px-3.5 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
              activeTab === 'completed'
                ? 'bg-purple-400 text-neutral-950 font-bold shadow-md'
                : 'bg-[#0e0f14] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
            }`}
          >
            Selesai ({counts.completed})
          </button>
        </div>

        {/* Search */}
        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nama klien / judul..."
            className="w-full bg-[#0e0f14] border border-neutral-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
          />
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length === 0 ? (
        <div className="text-center py-16 bg-[#0e0f14]/50 rounded-2xl border border-neutral-800/80 p-6">
          <Filter className="w-10 h-10 mx-auto text-neutral-600 mb-3" />
          <h3 className="text-base font-semibold text-neutral-300">Tidak ada project ditemukan</h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
            Tidak ada sesi foto yang sesuai dengan filter atau kata kunci saat ini.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
          {filteredProjects.map((project) => {
            const photoCount = getProjectPhotoCount(project.id);
            const statusInfo = getStatusBadge(project.status);
            const StatusIcon = statusInfo.icon;

            return (
              <div
                key={project.id}
                className="bg-[#0e0f14] border border-neutral-800/90 hover:border-neutral-700/90 rounded-2xl p-5 flex flex-col justify-between transition-all shadow-lg group"
              >
                <div>
                  {/* Card Top: Cover thumbnail & main info */}
                  <div className="flex gap-4">
                    <div className="w-24 h-24 rounded-xl overflow-hidden bg-[#07080a] shrink-0 border border-neutral-800 relative">
                      {project.coverPhotoUrl ? (
                        <img
                          src={project.coverPhotoUrl}
                          alt={project.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-neutral-600">
                          <ImageIcon className="w-6 h-6 mb-1" />
                          <span className="text-[10px]">No Photo</span>
                        </div>
                      )}
                      <div className="absolute top-1 left-1 bg-black/75 px-1.5 py-0.5 rounded text-[10px] font-medium text-neutral-300 capitalize">
                        {project.sessionType}
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border flex items-center gap-1 ${statusInfo.class}`}>
                          <StatusIcon className="w-3 h-3" />
                          <span>{statusInfo.label}</span>
                        </span>
                        <div className="text-[11px] text-neutral-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{project.sessionDate}</span>
                        </div>
                      </div>

                      <h3 className="text-base font-bold text-white font-display mt-1 truncate">
                        {project.title}
                      </h3>

                      <p className="text-xs text-neutral-300 font-medium">
                        {project.clientName}
                      </p>

                      {/* Security details */}
                      <div className="flex items-center gap-3 text-[11px] text-neutral-400 mt-2">
                        <span className="flex items-center gap-1">
                          <ImageIcon className="w-3 h-3 text-neutral-500" />
                          <span>{photoCount} Foto di Galeri</span>
                        </span>
                        {project.requiresPin && (
                          <span className="flex items-center gap-1 text-amber-400/90 font-mono">
                            <Lock className="w-3 h-3" />
                            <span>PIN: {project.pinCode}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Quota selection progress */}
                  <div className="mt-4 pt-3 border-t border-neutral-800/80">
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-neutral-400">Progres Seleksi Klien:</span>
                      <span className="font-mono font-bold text-neutral-200">
                        <strong className="text-amber-400">{project.currentSelectionsCount}</strong> / {project.allowedSelections} foto
                      </span>
                    </div>
                    <div className="w-full bg-[#14151c] h-1.5 rounded-full overflow-hidden border border-neutral-800/60">
                      <div
                        className={`h-full ${
                          project.currentSelectionsCount >= project.allowedSelections
                            ? 'bg-emerald-400'
                            : 'bg-gradient-to-r from-amber-500 to-amber-400'
                        }`}
                        style={{
                          width: `${Math.min(
                            100,
                            (project.currentSelectionsCount / project.allowedSelections) * 100
                          )}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="mt-5 pt-3.5 border-t border-neutral-800/80 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* Review Selections Button */}
                    <button
                      type="button"
                      onClick={() => onSelectProjectForReview(project)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
                        project.status === 'submitted'
                          ? 'bg-emerald-400 text-neutral-950 hover:bg-emerald-300 font-bold shadow-sm'
                          : 'bg-[#15161f] text-neutral-200 hover:bg-[#1e202c] border border-neutral-800'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Lihat Seleksi ({project.currentSelectionsCount})</span>
                    </button>

                    {/* Upload Photos Button */}
                    <button
                      type="button"
                      onClick={() => onOpenUploadModal(project)}
                      className="px-3 py-1.5 bg-[#15161f] hover:bg-[#1e202c] text-neutral-200 border border-neutral-800 rounded-xl text-xs font-medium flex items-center gap-1 transition-colors"
                      title="Upload foto massal ke sesi ini"
                    >
                      <UploadCloud className="w-3.5 h-3.5 text-amber-400" />
                      <span>Upload Foto</span>
                    </button>

                    {/* Share Client Link Button */}
                    <button
                      type="button"
                      onClick={() => onOpenShareModal(project)}
                      className="px-3 py-1.5 bg-[#15161f] hover:bg-[#1e202c] text-neutral-200 border border-neutral-800 rounded-xl text-xs font-medium flex items-center gap-1 transition-colors"
                      title="Kirim link galeri ke klien via WhatsApp"
                    >
                      <Share2 className="w-3.5 h-3.5 text-sky-400" />
                      <span>Link Klien</span>
                    </button>
                  </div>

                  {/* Secondary Client View & Delete */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onOpenClientView(project)}
                      className="p-2 text-neutral-400 hover:text-amber-400 rounded-xl hover:bg-[#15161f] transition-colors"
                      title="Uji coba tampilan dari mata Klien"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Yakin ingin menghapus project "${project.title}"? Seluruh foto dan seleksi akan dihapus.`)) {
                          onDeleteProject(project.id);
                        }
                      }}
                      className="p-2 text-neutral-500 hover:text-rose-400 rounded-xl hover:bg-[#15161f] transition-colors"
                      title="Hapus Project"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Demo Reset Notice */}
      <div className="pt-6 border-t border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-neutral-500">
        <p>
          * Data sesi & foto tersimpan otomatis secara persistent. Anda dapat mereset data ke sample awal kapan saja.
        </p>
        <button
          type="button"
          onClick={() => {
            if (confirm('Kembalikan semua project dan foto ke contoh data awal?')) {
              onResetDemoData();
            }
          }}
          className="flex items-center gap-1 text-neutral-400 hover:text-amber-400 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Sample Demo Data</span>
        </button>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Camera, Lock, Mail, KeyRound, ArrowRight, ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';
import { VendorProfile } from '../../types';

interface AdminLoginViewProps {
  vendor: VendorProfile;
  onLoginSuccess: () => void;
  onSwitchToClientDemo: () => void;
}

export const AdminLoginView: React.FC<AdminLoginViewProps> = ({
  vendor,
  onLoginSuccess,
  onSwitchToClientDemo,
}) => {
  const [email, setEmail] = useState('studio@noeticsortir.com');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    setTimeout(() => {
      // Allow any valid-looking login or demo password
      if (password.length >= 4) {
        onLoginSuccess();
      } else {
        setError('Password minimal 4 karakter (contoh: admin123).');
        setIsLoading(false);
      }
    }, 450);
  };

  const handleDemoLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      onLoginSuccess();
    }, 300);
  };

  return (
    <div className="min-h-screen bg-[#07080a] text-neutral-100 flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden">
      {/* Subtle luxury ambient glows */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md relative z-10">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-600 to-amber-400 text-slate-950 font-black shadow-xl shadow-amber-500/10 mb-4 border border-amber-300/20">
            <Camera className="w-7 h-7 stroke-[2.2]" />
          </div>
          <div className="flex items-center justify-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-amber-400/90 font-mono">
              Portal Fotografer & Vendor
            </span>
          </div>
          <h1 className="text-3xl font-display font-bold text-white tracking-tight">
            n0etic s0rtir
          </h1>
          <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
            {vendor.tagline || 'Visual Storytelling & Curated Photo Proofing'}
          </p>
        </div>

        {/* Login Box */}
        <div className="bg-[#0e0f14] border border-neutral-800/80 rounded-3xl p-7 sm:p-8 shadow-2xl backdrop-blur-xl relative">
          <div className="flex items-center justify-between pb-5 mb-5 border-b border-neutral-800/70">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-semibold text-neutral-200">Akses Khusus Admin Fotografer</span>
            </div>
            <span className="text-[10px] font-mono font-bold bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/20">
              Studio Pro
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-xl text-xs text-rose-300">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Email Studio / Admin
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@noeticsortir.com"
                  className="w-full bg-[#14151c] border border-neutral-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Kata Sandi Admin
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#14151c] border border-neutral-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-neutral-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/15 flex items-center justify-center gap-2 transition-all active:scale-[0.99] disabled:opacity-50"
            >
              <span>{isLoading ? 'Memverifikasi...' : 'Masuk ke Dashboard Admin'}</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </form>

          {/* Quick Demo Access Button */}
          <div className="mt-5 pt-5 border-t border-neutral-800/70 text-center space-y-2.5">
            <p className="text-[11px] text-neutral-500">
              Uji coba instan tanpa memasukkan kredensial manual:
            </p>
            <button
              type="button"
              onClick={handleDemoLogin}
              className="w-full py-2 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Masuk Cepat Demo Admin</span>
            </button>
          </div>
        </div>

        {/* Client Access Notice */}
        <div className="mt-6 text-center text-xs text-neutral-500 space-y-2">
          <p className="text-[11px] leading-relaxed">
            Halaman ini khusus untuk fotografer & manajemen studio.
            <br />
            Klien hanya dapat mengakses melalui <strong>link khusus sesi</strong> yang dikirimkan oleh fotografer.
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={onSwitchToClientDemo}
              className="text-amber-400 hover:text-amber-300 hover:underline text-xs inline-flex items-center gap-1 font-medium transition-colors"
            >
              <span>Buka Contoh Galeri Klien (Simulasi Link Klien)</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

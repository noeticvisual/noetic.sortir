import React, { useState } from 'react';
import { Project, PhotoItem, ActivityLog } from '../../types';
import { 
  X, Download, Copy, Check, CheckCircle2, MessageSquare, 
  Sparkles, FileText, ArrowLeft, Unlock, Clock, UserCheck 
} from 'lucide-react';
import { getLightroomFilterString, downloadSelectionsAsZip } from '../../services/storageService';

interface AdminSelectionReviewProps {
  project: Project;
  photos: PhotoItem[];
  logs: ActivityLog[];
  onBack: () => void;
  onTogglePhotoEdited: (photoId: string) => void;
  onMarkProjectCompleted: () => void;
  onUnlockSelection: () => void;
}

export const AdminSelectionReview: React.FC<AdminSelectionReviewProps> = ({
  project,
  photos,
  logs,
  onBack,
  onTogglePhotoEdited,
  onMarkProjectCompleted,
  onUnlockSelection,
}) => {
  const [copiedString, setCopiedString] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [filterView, setFilterView] = useState<'selected' | 'all'>('selected');

  const selectedPhotos = photos.filter((p) => p.isSelected);
  const lightroomString = getLightroomFilterString(photos);
  const editedCount = selectedPhotos.filter((p) => p.isEdited).length;

  const handleCopyLightroom = () => {
    navigator.clipboard.writeText(lightroomString);
    setCopiedString(true);
    setTimeout(() => setCopiedString(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadSelectionsAsZip(project, photos);
    } catch (err) {
      console.error('Download error:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07080a] text-neutral-100 pb-20">
      {/* Top Breadcrumb & Action Header */}
      <div className="bg-[#0a0b10] border-b border-neutral-800/80 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-[#14151c] text-neutral-400 hover:text-white hover:bg-neutral-800/80 border border-neutral-800 transition-colors"
              title="Kembali ke Dashboard"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
                  Hasil Seleksi Klien
                </span>
                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                  project.status === 'completed'
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : project.status === 'submitted'
                    ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                    : 'bg-neutral-800 text-neutral-400'
                }`}>
                  {project.status === 'completed' ? 'Selesai Diedit' : 'Siap Diedit (Submitted)'}
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold font-display text-white">
                {project.title}
              </h1>
              <p className="text-xs text-neutral-400">
                Klien: <strong className="text-neutral-200">{project.clientName}</strong> • {selectedPhotos.length} / {project.allowedSelections} Foto Dipilih
              </p>
            </div>
          </div>

          {/* Action Tools */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Copy Lightroom Filter Button */}
            <button
              type="button"
              onClick={handleCopyLightroom}
              className="px-3.5 py-2 bg-[#12131a] hover:bg-[#1a1c26] text-neutral-200 border border-neutral-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
              title="Salin deretan nama file untuk dipaste di Lightroom Library Search"
            >
              {copiedString ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
              <span>{copiedString ? 'Tersalin!' : 'Copy String Lightroom'}</span>
            </button>

            {/* Download Bulk ZIP */}
            <button
              type="button"
              disabled={isZipping || selectedPhotos.length === 0}
              onClick={handleDownloadZip}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 disabled:opacity-40 text-neutral-950 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-lg shadow-amber-500/10 active:scale-95"
            >
              <Download className="w-4 h-4 stroke-[2.2]" />
              <span>{isZipping ? 'Membuat ZIP...' : 'Download ZIP Foto Pilihan'}</span>
            </button>

            {/* Mark Finished Status */}
            {project.status !== 'completed' ? (
              <button
                type="button"
                onClick={onMarkProjectCompleted}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-md"
              >
                <CheckCircle2 className="w-4 h-4 stroke-[2.2]" />
                <span>Tandai Selesai Diedit</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onUnlockSelection}
                className="px-3.5 py-2 bg-[#14151c] hover:bg-[#1c1e2a] border border-neutral-800 text-neutral-300 rounded-xl text-xs font-medium flex items-center gap-1.5"
                title="Buka kembali jika klien minta ganti foto"
              >
                <Unlock className="w-4 h-4 text-amber-400" />
                <span>Buka Akses Klien (Revisi)</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Client Final Message / Summary Card */}
        {project.finalClientNotes && (
          <div className="p-4 bg-amber-950/20 border border-amber-500/30 rounded-2xl flex items-start gap-3">
            <MessageSquare className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs">
              <span className="font-bold text-amber-300 uppercase tracking-wider">
                Catatan Umum dari Klien ({project.clientName}):
              </span>
              <p className="text-neutral-200 mt-1 italic text-sm font-serif leading-relaxed">
                &ldquo;{project.finalClientNotes}&rdquo;
              </p>
            </div>
          </div>
        )}

        {/* Lightroom Search String Box */}
        <div className="bg-[#0e0f14] border border-neutral-800/80 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                Lightroom / Capture One Quick Search Filename String
              </span>
            </div>
            <button
              onClick={handleCopyLightroom}
              className="text-xs text-amber-400 hover:text-amber-300 hover:underline font-medium"
            >
              {copiedString ? 'Berhasil Disalin!' : 'Salin Teks'}
            </button>
          </div>
          <div className="p-3 bg-[#07080a] rounded-xl border border-neutral-800 font-mono text-xs text-neutral-300 select-all overflow-x-auto">
            {lightroomString || 'Belum ada foto yang dipilih oleh klien.'}
          </div>
          <p className="text-[11px] text-neutral-500">
            * Tip Fotografer: Di Lightroom Library, buka Text Filter, pilih <code>Filename &gt; Contains</code>, lalu paste string di atas untuk memfilter foto mentah langsung.
          </p>
        </div>

        {/* Progress & Tab Filter */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setFilterView('selected')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                filterView === 'selected'
                  ? 'bg-amber-400 text-neutral-950 font-bold'
                  : 'bg-[#12131a] text-neutral-400 hover:text-neutral-200 border border-neutral-800'
              }`}
            >
              Hanya Pilihan Klien ({selectedPhotos.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterView('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                filterView === 'all'
                  ? 'bg-amber-400 text-neutral-950 font-bold'
                  : 'bg-[#12131a] text-neutral-400 hover:text-neutral-200 border border-neutral-800'
              }`}
            >
              Semua Foto Galeri ({photos.length})
            </button>
          </div>

          <div className="text-xs text-neutral-400 flex items-center gap-3">
            <span>
              Status Editing: <strong className="text-white">{editedCount}</strong> dari {selectedPhotos.length} foto selesai
            </span>
          </div>
        </div>

        {/* Photos Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {(filterView === 'selected' ? selectedPhotos : photos).map((photo) => (
            <div
              key={photo.id}
              className={`bg-[#0e0f14] border rounded-2xl overflow-hidden flex flex-col transition-all ${
                photo.isSelected
                  ? 'border-amber-500/50 shadow-lg shadow-amber-500/5'
                  : 'border-neutral-800/80 opacity-60'
              }`}
            >
              <div className="relative aspect-[4/3] bg-[#07080a]">
                <img
                  src={photo.thumbnailUrl}
                  alt={photo.fileName}
                  className="w-full h-full object-cover"
                />
                {/* Selection badge */}
                <div className="absolute top-2 left-2 flex items-center gap-1 bg-black/75 backdrop-blur-xs text-amber-400 px-2 py-0.5 rounded-lg text-[11px] font-mono font-bold border border-white/10">
                  <span>{photo.isSelected ? 'Dipilih' : 'Tidak Dipilih'}</span>
                </div>
                {photo.isFavorite && (
                  <div className="absolute top-2 right-2 bg-rose-600 text-white p-1 rounded-full text-xs">
                    ★
                  </div>
                )}
              </div>

              {/* Photo Card Details */}
              <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between text-xs">
                <div>
                  <p className="font-mono text-neutral-200 font-semibold truncate">{photo.fileName}</p>
                  <p className="text-[11px] text-neutral-500">
                    {(photo.fileSize / (1024 * 1024)).toFixed(1)} MB • {photo.category || 'General'}
                  </p>
                </div>

                {/* Client Note snippet */}
                {photo.clientNote ? (
                  <div className="p-2.5 bg-amber-950/30 border border-amber-900/50 rounded-xl text-amber-200 text-[11px]">
                    <div className="flex items-center gap-1 font-semibold text-amber-400 mb-0.5">
                      <MessageSquare className="w-3 h-3" />
                      <span>Request Edit Klien:</span>
                    </div>
                    &ldquo;{photo.clientNote}&rdquo;
                  </div>
                ) : (
                  <p className="text-[11px] text-neutral-600 italic">Tidak ada catatan retouch khusus</p>
                )}

                {/* Checkbox: Mark as edited */}
                {photo.isSelected && (
                  <label className="flex items-center gap-2 pt-2.5 border-t border-neutral-800/80 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={photo.isEdited || false}
                      onChange={() => onTogglePhotoEdited(photo.id)}
                      className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                    />
                    <span className={`text-[11px] font-medium ${photo.isEdited ? 'text-emerald-400 font-bold' : 'text-neutral-400'}`}>
                      {photo.isEdited ? 'Sudah Selesai Diedit' : 'Tandai Selesai Diedit'}
                    </span>
                  </label>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Project Activity Audit Trail Log */}
        <div className="bg-[#0e0f14] border border-neutral-800/80 rounded-2xl p-6 mt-8 space-y-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Riwayat Aktivitas & Log Seleksi
            </h3>
          </div>
          <div className="divide-y divide-neutral-800/80 text-xs">
            {logs.length === 0 ? (
              <p className="text-neutral-500 py-3">Belum ada catatan aktivitas tercatat.</p>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="py-2.5 flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        log.actor === 'client' ? 'bg-amber-500/20 text-amber-400' : 'bg-neutral-800 text-neutral-300'
                      }`}>
                        {log.actor === 'client' ? 'Klien' : 'Admin Fotografer'}
                      </span>
                      <strong className="text-neutral-200">{log.action}</strong>
                    </div>
                    <p className="text-neutral-400 mt-0.5">{log.description}</p>
                  </div>
                  <span className="text-[11px] text-neutral-500 shrink-0 font-mono">
                    {new Date(log.timestamp).toLocaleString('id-ID')}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

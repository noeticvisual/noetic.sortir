import React from 'react';
import { Project, VendorProfile } from '../types';
import { Camera, ShieldCheck, LogOut, MessageCircle, ExternalLink } from 'lucide-react';

interface NavbarProps {
  currentMode: 'admin' | 'client';
  activeProject?: Project;
  vendor: VendorProfile;
  isAdminAuthenticated: boolean;
  onLogoutAdmin?: () => void;
  onReturnToAdmin?: () => void;
  isDirectClientLink?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentMode,
  activeProject,
  vendor,
  isAdminAuthenticated,
  onLogoutAdmin,
  onReturnToAdmin,
  isDirectClientLink,
}) => {
  // CLIENT VIEW HEADER
  if (currentMode === 'client') {
    return (
      <header className="bg-[#07080a]/95 backdrop-blur-md border-b border-neutral-800/80 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Studio Brand */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 text-neutral-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/10">
              <Camera className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-white text-base tracking-tight">
                  n0etic s0rtir
                </span>
                <span className="text-[10px] font-mono font-bold bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/20">
                  Client Portal
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 truncate max-w-[150px] sm:max-w-xs">
                {activeProject?.title ? activeProject.title : vendor.name}
              </p>
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            {/* If photographer is logged in and previewing, give them quick back-to-dashboard */}
            {isAdminAuthenticated && !isDirectClientLink && (
              <button
                type="button"
                onClick={onReturnToAdmin}
                className="px-3 py-1.5 bg-[#14151c] hover:bg-[#1f212e] text-neutral-200 border border-neutral-700/60 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-sm"
                title="Sesi Fotografer Aktif: Kembali ke Dashboard Admin"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Kembali ke Dashboard Admin</span>
                <span className="sm:hidden">Admin</span>
              </button>
            )}

            {/* Help / WhatsApp Contact for Client */}
            {vendor.phone && (
              <a
                href={`https://wa.me/${vendor.phone.replace(/[^0-9]/g, '')}?text=Halo%20${encodeURIComponent(vendor.name)},%20saya%20klien%20${encodeURIComponent(activeProject?.clientName || '')}%20ingin%20bertanya%20tentang%20pemilihan%20foto.`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 bg-[#12131a] hover:bg-[#1a1c26] text-neutral-300 hover:text-white border border-neutral-800 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors"
                title="Hubungi Fotografer via WhatsApp"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden md:inline">Bantuan Vendor</span>
              </a>
            )}
          </div>
        </div>
      </header>
    );
  }

  // ADMIN VIEW HEADER (Shown when currentMode === 'admin' and user is authenticated)
  return (
    <header className="bg-[#07080a]/95 backdrop-blur-md border-b border-neutral-800/80 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Logo & Studio Name */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 text-neutral-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/10">
            <Camera className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-white text-base tracking-tight">
                n0etic s0rtir
              </span>
              <span className="text-[10px] font-mono font-bold bg-amber-500/15 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/30">
                Admin Studio
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 truncate max-w-[150px] sm:max-w-xs">
              {vendor.name}
            </p>
          </div>
        </div>

        {/* Admin Right Bar */}
        <div className="flex items-center gap-2.5">
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-neutral-400 bg-[#12131a] px-3 py-1.5 rounded-xl border border-neutral-800">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-neutral-300">Admin Mode</span>
          </div>

          {onLogoutAdmin && (
            <button
              type="button"
              onClick={onLogoutAdmin}
              className="px-3 py-1.5 bg-[#14151c] hover:bg-rose-950/40 hover:text-rose-300 text-neutral-400 border border-neutral-800 hover:border-rose-800/50 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Kunci / Keluar dari Dashboard Admin"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Keluar</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

import React, { useState } from 'react';
import { Project, PhotoItem } from '../../types';
import { 
  X, CheckCircle, AlertTriangle, Send, MessageCircle, 
  Sparkles, FileText, Check 
} from 'lucide-react';

interface SubmitSelectionModalProps {
  isOpen: boolean;
  project: Project;
  photos: PhotoItem[];
  vendorPhone?: string;
  vendorName?: string;
  onClose: () => void;
  onSubmit: (clientNotes: string) => void;
}

export const SubmitSelectionModal: React.FC<SubmitSelectionModalProps> = ({
  isOpen,
  project,
  photos,
  vendorPhone = '6281234567890',
  vendorName = 'n0etic s0rtir',
  onClose,
  onSubmit,
}) => {
  const [generalNote, setGeneralNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmittedSuccess, setIsSubmittedSuccess] = useState(false);

  if (!isOpen) return null;

  const selectedPhotos = photos.filter((p) => p.isSelected);
  const quota = project.allowedSelections;
  const isExactQuota = selectedPhotos.length === quota;
  const isOverQuota = selectedPhotos.length > quota;

  const handleSubmit = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      onSubmit(generalNote);
      setIsSubmitting(false);
      setIsSubmittedSuccess(true);
    }, 600);
  };

  const handleWhatsAppConfirm = () => {
    const cleanPhone = vendorPhone.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Halo Kak Admin ${vendorName},\n\nSaya (${project.clientName}) sudah selesai memilih dan mengirim ${selectedPhotos.length} foto untuk project "${project.title}".\n\nMohon dicek ya kak, terima kasih!`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0e0f14] border border-neutral-800/90 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-500/20">
              <Sparkles className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-display">
                {isSubmittedSuccess ? 'Pilihan Berhasil Dikirim!' : 'Submit Pilihan Foto Final'}
              </h2>
              <p className="text-xs text-neutral-400">
                {project.title} • {project.clientName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1.5 rounded-xl hover:bg-neutral-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        {isSubmittedSuccess ? (
          <div className="p-6 sm:p-8 text-center flex flex-col items-center justify-center space-y-4">
            <div className="w-16 h-16 bg-emerald-500/15 text-emerald-400 rounded-2xl flex items-center justify-center ring-4 ring-emerald-500/10 border border-emerald-500/30 animate-pulse">
              <CheckCircle className="w-9 h-9 stroke-[2.2]" />
            </div>
            <h3 className="text-xl font-bold text-white font-display">Terima Kasih, {project.clientName}!</h3>
            <p className="text-sm text-neutral-300 max-w-md">
              Sebanyak <strong className="text-amber-400 font-mono">{selectedPhotos.length} foto pilihan</strong> Anda telah berhasil dikunci dan dikirim ke tim fotografer <strong>{vendorName}</strong>.
            </p>

            <div className="bg-[#12131a] p-4 rounded-2xl border border-neutral-800/80 text-left w-full text-xs text-neutral-300 space-y-2.5 mt-4">
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-500">Status Seleksi:</span>
                <span className="text-emerald-400 font-semibold">Terkunci & Siap Edit</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-500">Total Foto Dipilih:</span>
                <span className="text-white font-mono font-bold">{selectedPhotos.length} Foto</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-neutral-500">Estimasi Pengerjaan:</span>
                <span className="text-amber-400 font-semibold">7 - 14 Hari Kerja</span>
              </div>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row gap-3 w-full">
              <button
                type="button"
                onClick={handleWhatsAppConfirm}
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all text-xs active:scale-95"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Konfirmasi via WhatsApp</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium py-3 px-6 rounded-xl transition-colors text-xs"
              >
                Kembali ke Galeri
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 overflow-y-auto space-y-5 flex-1">
            {/* Status quota pill */}
            <div className={`p-4 rounded-2xl border flex items-start gap-3 ${
              isOverQuota 
                ? 'bg-rose-950/30 border-rose-800/50 text-rose-300'
                : isExactQuota 
                ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300'
                : 'bg-amber-950/30 border-amber-800/50 text-amber-300'
            }`}>
              <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
              <div className="text-xs sm:text-sm">
                <p className="font-semibold">
                  {selectedPhotos.length} dari {quota} Foto Paket Telah Dipilih
                </p>
                <p className="text-neutral-400 mt-0.5 text-xs">
                  {isOverQuota 
                    ? `Pilihan Anda melebihi kuota paket (${quota} foto). Silakan batalkan beberapa foto.` 
                    : isExactQuota 
                    ? `Sempurna! Kuota paket ${quota} foto telah pas terisi.`
                    : `Anda masih dapat memilih ${quota - selectedPhotos.length} foto lagi sebelum submit.`
                  }
                </p>
              </div>
            </div>

            {/* Selected Thumbnail Grid */}
            <div>
              <label className="text-[11px] font-semibold text-neutral-300 uppercase tracking-wider block mb-2">
                Daftar Foto yang Anda Pilih ({selectedPhotos.length})
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-h-48 overflow-y-auto p-2 bg-[#07080a] rounded-2xl border border-neutral-800/80">
                {selectedPhotos.map((photo, i) => (
                  <div key={photo.id} className="relative aspect-square rounded-xl overflow-hidden border border-neutral-800 group">
                    <img 
                      src={photo.thumbnailUrl} 
                      alt={photo.fileName} 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute top-1 left-1 bg-black/75 text-amber-400 text-[10px] font-mono px-1.5 rounded-md">
                      #{i + 1}
                    </div>
                    {photo.clientNote && (
                      <div className="absolute bottom-1 right-1 bg-amber-400 text-neutral-950 p-1 rounded-full" title={photo.clientNote}>
                        <FileText className="w-2.5 h-2.5" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Notes with items summary */}
            {selectedPhotos.some((p) => p.clientNote) && (
              <div className="bg-[#12131a] rounded-2xl p-3.5 border border-neutral-800/80 text-xs space-y-1.5 max-h-36 overflow-y-auto">
                <p className="font-semibold text-amber-400">Catatan Khusus pada Foto:</p>
                {selectedPhotos
                  .filter((p) => p.clientNote)
                  .map((p) => (
                    <div key={p.id} className="text-neutral-300 flex items-start gap-1">
                      <span className="font-mono text-amber-400 font-medium shrink-0">{p.fileName}:</span>
                      <span className="italic text-neutral-400">&ldquo;{p.clientNote}&rdquo;</span>
                    </div>
                  ))}
              </div>
            )}

            {/* General Note for Photographer */}
            <div>
              <label className="text-[11px] font-semibold text-neutral-300 uppercase tracking-wider block mb-1.5">
                Catatan Umum untuk Fotografer (Opsional)
              </label>
              <textarea
                value={generalNote}
                onChange={(e) => setGeneralNote(e.target.value)}
                placeholder="Contoh: Tolong tone warnanya dibuat lebih warm dan natural ya kak. Hasilnya mohon diinfo via WhatsApp..."
                rows={3}
                className="w-full bg-[#12131a] border border-neutral-800 rounded-xl p-3 text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>

            {/* Lock Notice */}
            <p className="text-[11px] text-neutral-500 leading-relaxed">
              * Perhatian: Setelah menekan tombol <strong>Kirim Pilihan Final</strong>, pilihan foto akan dikunci agar fotografer dapat langsung mengunduh dan memulai proses retouching profesional.
            </p>
          </div>
        )}

        {/* Footer */}
        {!isSubmittedSuccess && (
          <div className="px-6 py-4 bg-[#0a0b10] border-t border-neutral-800/80 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="text-xs sm:text-sm text-neutral-400 hover:text-white px-3 py-2 transition-colors"
            >
              Cek Kembali Foto
            </button>
            <button
              type="button"
              disabled={isSubmitting || selectedPhotos.length === 0 || isOverQuota}
              onClick={handleSubmit}
              className="bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 disabled:opacity-40 disabled:cursor-not-allowed text-neutral-950 font-bold px-6 py-2.5 rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-amber-500/10 transition-all active:scale-95"
            >
              {isSubmitting ? (
                <span>Mengirim...</span>
              ) : (
                <>
                  <Send className="w-4 h-4 stroke-[2.2]" />
                  <span>Kirim Pilihan Final ({selectedPhotos.length} Foto)</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

import React from 'react';
import { PhotoItem, WatermarkConfig } from '../../types';
import { WatermarkOverlay } from '../WatermarkOverlay';
import { Check, Heart, MessageSquare, Maximize2 } from 'lucide-react';

interface PhotoCardProps {
  photo: PhotoItem;
  watermarkConfig: WatermarkConfig;
  vendorName: string;
  isLocked: boolean;
  onToggleSelect: () => void;
  onToggleFavorite: () => void;
  onOpenLightbox: () => void;
  onAddNote: () => void;
}

export const PhotoCard: React.FC<PhotoCardProps> = ({
  photo,
  watermarkConfig,
  vendorName,
  isLocked,
  onToggleSelect,
  onToggleFavorite,
  onOpenLightbox,
  onAddNote,
}) => {
  return (
    <div
      className={`group relative rounded-2xl overflow-hidden bg-[#0e0f14] border transition-all duration-300 ${
        photo.isSelected
          ? 'border-amber-400 shadow-[0_0_25px_rgba(245,158,11,0.2)] ring-1 ring-amber-400'
          : 'border-neutral-800/80 hover:border-neutral-700 hover:shadow-xl'
      }`}
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Image with Protection */}
      <div
        className="relative aspect-[4/3] w-full overflow-hidden bg-[#07080a] cursor-pointer protected-photo"
        onClick={onOpenLightbox}
      >
        <img
          src={photo.thumbnailUrl}
          alt={photo.fileName}
          loading="lazy"
          className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${
            photo.isSelected ? 'brightness-100' : 'brightness-95'
          }`}
          draggable={false}
        />

        {/* Watermark Overlay */}
        <WatermarkOverlay config={watermarkConfig} vendorName={vendorName} />

        {/* Zoom Hint on Hover */}
        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <div className="bg-black/75 backdrop-blur-md text-white/95 px-3.5 py-1.5 rounded-full text-xs flex items-center gap-1.5 shadow-xl border border-white/10">
            <Maximize2 className="w-3.5 h-3.5 text-amber-400" />
            <span>Klik untuk Perbesar</span>
          </div>
        </div>

        {/* Category Pill */}
        {photo.category && (
          <div className="absolute bottom-2.5 left-2.5 z-20 pointer-events-none">
            <span className="bg-black/75 backdrop-blur-md text-neutral-300 text-[10px] font-medium px-2 py-0.5 rounded-md capitalize border border-white/10">
              {photo.category}
            </span>
          </div>
        )}
      </div>

      {/* Floating Action Controls on Card (Top Bar) */}
      <div className="absolute top-2.5 inset-x-2.5 flex items-center justify-between z-30 pointer-events-none">
        {/* Favorite Heart Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite();
          }}
          title={photo.isFavorite ? 'Hapus dari Favorit' : 'Tandai Favorit'}
          className={`pointer-events-auto p-2 rounded-full backdrop-blur-md transition-transform active:scale-90 shadow-md ${
            photo.isFavorite
              ? 'bg-rose-500 text-white hover:bg-rose-600'
              : 'bg-black/60 text-white/90 hover:bg-black/80 hover:text-white border border-white/10'
          }`}
        >
          <Heart
            className={`w-4 h-4 ${photo.isFavorite ? 'fill-current' : ''}`}
          />
        </button>

        {/* Big Selection Checkbox */}
        <button
          type="button"
          disabled={isLocked}
          onClick={(e) => {
            e.stopPropagation();
            onToggleSelect();
          }}
          title={
            isLocked
              ? 'Seleksi sudah dikunci'
              : photo.isSelected
              ? 'Batalkan Pilihan'
              : 'Pilih Foto Ini untuk Diedit'
          }
          className={`pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 rounded-full font-semibold text-xs transition-all shadow-md active:scale-95 ${
            photo.isSelected
              ? 'bg-gradient-to-r from-amber-400 to-amber-300 text-neutral-950 hover:from-amber-300 hover:to-amber-200 font-bold ring-2 ring-white/30'
              : 'bg-black/70 text-white hover:bg-amber-400 hover:text-black backdrop-blur-md border border-white/20'
          } ${isLocked ? 'opacity-75 cursor-not-allowed' : 'cursor-pointer'}`}
        >
          <Check className={`w-3.5 h-3.5 stroke-[3] ${photo.isSelected ? 'text-neutral-950' : 'text-white'}`} />
          <span>{photo.isSelected ? 'Dipilih' : 'Pilih'}</span>
        </button>
      </div>

      {/* Bottom Info & Note Bar */}
      <div className="p-3 bg-[#111218] border-t border-neutral-800/80 flex items-center justify-between text-xs">
        <div className="truncate pr-2">
          <p className="font-mono text-neutral-200 font-medium truncate">{photo.fileName}</p>
          <p className="text-[11px] text-neutral-500">
            {(photo.fileSize / (1024 * 1024)).toFixed(1)} MB
          </p>
        </div>

        {/* Note Action */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onAddNote();
          }}
          disabled={isLocked}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
            photo.clientNote
              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 hover:bg-amber-500/25'
              : 'bg-neutral-800/80 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
          }`}
          title={photo.clientNote ? `Catatan: ${photo.clientNote}` : 'Tambahkan catatan retouch untuk fotografer'}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>{photo.clientNote ? 'Ada Catatan' : '+ Catatan'}</span>
        </button>
      </div>

      {/* Mini note preview snippet if present */}
      {photo.clientNote && (
        <div className="px-3 pb-2.5 pt-0 bg-[#111218]">
          <p className="text-[11px] text-amber-300/90 italic bg-amber-950/30 p-1.5 rounded-lg border border-amber-800/40 truncate">
            &ldquo;{photo.clientNote}&rdquo;
          </p>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { PhotoItem, WatermarkConfig } from '../../types';
import { WatermarkOverlay } from '../WatermarkOverlay';
import { 
  X, ChevronLeft, ChevronRight, Check, Heart, 
  ZoomIn, ZoomOut, MessageSquare, Info, ShieldCheck 
} from 'lucide-react';

interface LightboxModalProps {
  photos: PhotoItem[];
  currentIndex: number;
  isOpen: boolean;
  watermarkConfig: WatermarkConfig;
  vendorName: string;
  isLocked: boolean;
  quotaMax: number;
  quotaSelected: number;
  onClose: () => void;
  onNavigate: (newIndex: number) => void;
  onToggleSelect: (photoId: string) => void;
  onToggleFavorite: (photoId: string) => void;
  onUpdateNote: (photoId: string, note: string) => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  photos,
  currentIndex,
  isOpen,
  watermarkConfig,
  vendorName,
  isLocked,
  quotaMax,
  quotaSelected,
  onClose,
  onNavigate,
  onToggleSelect,
  onToggleFavorite,
  onUpdateNote,
}) => {
  const [isZoomed, setIsZoomed] = useState(false);
  const [showNoteEditor, setShowNoteEditor] = useState(false);
  const [currentNote, setCurrentNote] = useState('');

  const photo = photos[currentIndex];

  useEffect(() => {
    if (photo) {
      setCurrentNote(photo.clientNote || '');
    }
    setIsZoomed(false);
  }, [photo]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' && currentIndex < photos.length - 1) {
        onNavigate(currentIndex + 1);
      }
      if (e.key === 'ArrowLeft' && currentIndex > 0) {
        onNavigate(currentIndex - 1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentIndex, photos.length, onNavigate, onClose]);

  if (!isOpen || !photo) return null;

  const handleSaveNote = () => {
    onUpdateNote(photo.id, currentNote);
    setShowNoteEditor(false);
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col select-none"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/50 border-b border-white/10 z-40">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            title="Tutup (Esc)"
          >
            <X className="w-6 h-6" />
          </button>
          <div>
            <h3 className="text-white text-sm sm:text-base font-semibold font-mono truncate max-w-[200px] sm:max-w-md">
              {photo.fileName}
            </h3>
            <p className="text-xs text-white/50">
              Foto {currentIndex + 1} dari {photos.length} • {(photo.fileSize / (1024 * 1024)).toFixed(1)} MB
            </p>
          </div>
        </div>

        {/* Action Controls in Top Bar */}
        <div className="flex items-center gap-2">
          {/* Zoom Button */}
          <button
            onClick={() => setIsZoomed(!isZoomed)}
            className="p-2 rounded-lg bg-white/10 text-white/90 hover:bg-white/20 transition-colors hidden sm:flex items-center gap-1 text-xs"
            title={isZoomed ? 'Zoom Normal' : 'Perbesar Gambar'}
          >
            {isZoomed ? <ZoomOut className="w-4 h-4" /> : <ZoomIn className="w-4 h-4" />}
            <span>{isZoomed ? '100%' : 'Zoom'}</span>
          </button>

          {/* Favorite Button */}
          <button
            onClick={() => onToggleFavorite(photo.id)}
            className={`p-2 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-medium ${
              photo.isFavorite
                ? 'bg-rose-600 text-white'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
            title="Tandai Favorit"
          >
            <Heart className={`w-4 h-4 ${photo.isFavorite ? 'fill-current' : ''}`} />
            <span className="hidden sm:inline">Favorit</span>
          </button>

          {/* Big Select Button */}
          <button
            disabled={isLocked}
            onClick={() => onToggleSelect(photo.id)}
            className={`px-4 py-2 rounded-lg flex items-center gap-2 text-xs sm:text-sm font-bold transition-all shadow-lg active:scale-95 ${
              photo.isSelected
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                : 'bg-white/15 text-white hover:bg-amber-500 hover:text-black border border-white/20'
            } ${isLocked ? 'opacity-60 cursor-not-allowed' : ''}`}
          >
            <Check className={`w-4 h-4 stroke-[3] ${photo.isSelected ? 'text-slate-950' : 'text-white'}`} />
            <span>{photo.isSelected ? 'Foto Terpilih' : 'Pilih Foto Ini'}</span>
          </button>
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden p-2 sm:p-6">
        {/* Prev Button */}
        {currentIndex > 0 && (
          <button
            onClick={() => onNavigate(currentIndex - 1)}
            className="absolute left-3 top-1/2 -translate-y-1/2 z-40 p-3 rounded-full bg-black/60 hover:bg-black/80 text-white transition-all backdrop-blur-sm border border-white/10"
            title="Foto Sebelumnya (Panah Kiri)"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Next Button */}
        {currentIndex < photos.length - 1 && (
          <button
            onClick={() => onNavigate(currentIndex + 1)}
            className="absolute right-3 top-1/2 -translate-y-1/2 z-40 p-3 rounded-full bg-black/60 hover:bg-black/80 text-white transition-all backdrop-blur-sm border border-white/10"
            title="Foto Selanjutnya (Panah Kanan)"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}

        {/* Image Display with Watermark */}
        <div 
          className={`relative max-w-full max-h-full transition-all duration-300 flex items-center justify-center protected-photo ${
            isZoomed ? 'scale-125 cursor-grab overflow-auto' : 'cursor-default'
          }`}
          onClick={() => !isZoomed && setIsZoomed(true)}
        >
          <img
            src={photo.originalUrl}
            alt={photo.fileName}
            className="max-h-[calc(100vh-140px)] max-w-[calc(100vw-40px)] object-contain rounded-lg shadow-2xl pointer-events-none select-none"
            draggable={false}
          />
          <WatermarkOverlay config={watermarkConfig} vendorName={vendorName} />
        </div>
      </div>

      {/* Bottom Bar / Retouch Note Panel */}
      <div className="bg-[#0a0b10] border-t border-neutral-800/80 p-3 sm:p-4 z-40">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Note Status & Toggle */}
          <div className="flex-1">
            {showNoteEditor ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={currentNote}
                  onChange={(e) => setCurrentNote(e.target.value)}
                  placeholder="Tulis request edit: e.g. hilangkan noda baju, cerahkan wajah..."
                  className="flex-1 bg-[#12131a] border border-amber-500/50 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveNote();
                  }}
                />
                <button
                  onClick={handleSaveNote}
                  className="px-3.5 py-2 bg-gradient-to-r from-amber-400 to-amber-300 text-neutral-950 text-xs font-bold rounded-xl hover:from-amber-300 hover:to-amber-200 transition-all shadow-md"
                >
                  Simpan
                </button>
                <button
                  onClick={() => setShowNoteEditor(false)}
                  className="px-3.5 py-2 bg-neutral-800 text-neutral-300 text-xs rounded-xl hover:bg-neutral-700 transition-colors"
                >
                  Batal
                </button>
              </div>
            ) : (
              <div 
                onClick={() => !isLocked && setShowNoteEditor(true)}
                className={`flex items-center gap-2 p-2 rounded-xl cursor-pointer transition-colors ${
                  photo.clientNote
                    ? 'bg-amber-950/30 border border-amber-500/30 text-amber-200'
                    : 'bg-[#12131a] border border-neutral-800 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="text-xs sm:text-sm truncate">
                  {photo.clientNote ? (
                    <span><strong>Catatan Edit:</strong> &ldquo;{photo.clientNote}&rdquo;</span>
                  ) : (
                    <span>+ Tambah catatan khusus untuk foto ini (klik disini)</span>
                  )}
                </span>
                {!isLocked && (
                  <span className="text-[10px] text-amber-400 font-medium underline ml-auto shrink-0">
                    {photo.clientNote ? 'Edit Catatan' : 'Tambah'}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Quota Indicator */}
          <div className="flex items-center justify-between sm:justify-end gap-3 text-xs text-neutral-400 border-t sm:border-t-0 pt-2 sm:pt-0 border-neutral-800">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Watermark Aktif</span>
            </div>
            <div className="h-4 w-px bg-neutral-800 hidden sm:block" />
            <div className="font-medium text-neutral-300">
              Dipilih: <span className="text-amber-400 font-bold">{quotaSelected}</span> / {quotaMax} foto
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { Project, PhotoItem, VendorProfile, PhotoCategory } from '../../types';
import { PhotoCard } from './PhotoCard';
import { LightboxModal } from './LightboxModal';
import { SubmitSelectionModal } from './SubmitSelectionModal';
import { PinGateView } from './PinGateView';
import { 
  Check, Heart, Filter, Search, Sparkles, AlertCircle, 
  Lock, CheckCircle2, SlidersHorizontal, RefreshCw, Eye 
} from 'lucide-react';

interface ClientGalleryViewProps {
  project: Project;
  photos: PhotoItem[];
  vendor: VendorProfile;
  onToggleSelect: (photoId: string) => void;
  onToggleFavorite: (photoId: string) => void;
  onUpdateNote: (photoId: string, note: string) => void;
  onSubmitFinal: (clientNotes: string) => void;
  onSwitchToAdmin?: () => void;
}

export const ClientGalleryView: React.FC<ClientGalleryViewProps> = ({
  project,
  photos,
  vendor,
  onToggleSelect,
  onToggleFavorite,
  onUpdateNote,
  onSubmitFinal,
  onSwitchToAdmin,
}) => {
  const [isUnlocked, setIsUnlocked] = useState(!project.requiresPin);
  const [filterType, setFilterType] = useState<'all' | 'selected' | 'favorites' | 'unselected'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Lightbox State
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  
  // Submit Modal State
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);

  // Note Modal / Quick Note Editor
  const [activeNotePhotoId, setActiveNotePhotoId] = useState<string | null>(null);
  const [tempNoteText, setTempNoteText] = useState('');

  const isLocked = project.status === 'submitted' || project.status === 'completed';

  // Stats
  const selectedCount = useMemo(() => photos.filter((p) => p.isSelected).length, [photos]);
  const favoriteCount = useMemo(() => photos.filter((p) => p.isFavorite).length, [photos]);
  const progressPercent = Math.min(100, Math.round((selectedCount / project.allowedSelections) * 100));

  // Available categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    photos.forEach((p) => {
      if (p.category) set.add(p.category);
    });
    return Array.from(set);
  }, [photos]);

  // Filtered Photos
  const filteredPhotos = useMemo(() => {
    return photos.filter((photo) => {
      // Status Filter
      if (filterType === 'selected' && !photo.isSelected) return false;
      if (filterType === 'favorites' && !photo.isFavorite) return false;
      if (filterType === 'unselected' && photo.isSelected) return false;

      // Category Filter
      if (selectedCategory !== 'all' && photo.category !== selectedCategory) return false;

      // Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchName = photo.fileName.toLowerCase().includes(query);
        const matchNote = photo.clientNote?.toLowerCase().includes(query);
        if (!matchName && !matchNote) return false;
      }

      return true;
    });
  }, [photos, filterType, selectedCategory, searchQuery]);

  if (!isUnlocked) {
    return (
      <PinGateView
        project={project}
        vendorName={vendor.name}
        onUnlock={() => setIsUnlocked(true)}
      />
    );
  }

  const handleOpenNoteEditor = (photo: PhotoItem) => {
    setActiveNotePhotoId(photo.id);
    setTempNoteText(photo.clientNote || '');
  };

  const handleSaveNote = () => {
    if (activeNotePhotoId) {
      onUpdateNote(activeNotePhotoId, tempNoteText);
      setActiveNotePhotoId(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#07080a] text-neutral-100 pb-28 select-none protected-photo">
      {/* Client Header Banner */}
      <header className="relative bg-[#0a0b10] border-b border-neutral-800/80 overflow-hidden">
        {project.coverPhotoUrl && (
          <div className="absolute inset-0 opacity-20">
            <img 
              src={project.coverPhotoUrl} 
              alt={project.title} 
              className="w-full h-full object-cover blur-md"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07080a] via-[#07080a]/85 to-transparent" />
          </div>
        )}

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20 font-mono">
                  {vendor.name} • Proofing Gallery
                </span>
                {project.status === 'submitted' && (
                  <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Pilihan Dikunci
                  </span>
                )}
              </div>
              <h1 className="text-2xl sm:text-4xl font-bold font-display text-white tracking-tight">
                {project.title}
              </h1>
              <p className="text-xs sm:text-sm text-neutral-400">
                Halo, <strong className="text-neutral-200">{project.clientName}</strong>! Silakan pilih foto terbaik Anda untuk diproses retouching profesional.
              </p>
            </div>

            {/* Quick Action in Header */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsSubmitModalOpen(true)}
                disabled={isLocked}
                className={`px-5 py-2.5 rounded-xl font-bold text-xs shadow-xl flex items-center gap-2 transition-all active:scale-95 ${
                  isLocked
                    ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 cursor-default'
                    : selectedCount >= project.allowedSelections
                    ? 'bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-neutral-950 shadow-amber-500/20 animate-pulse'
                    : 'bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-neutral-950'
                }`}
              >
                {isLocked ? (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Seleksi Sudah Disubmit</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 stroke-[2.2]" />
                    <span>Submit Pilihan Final ({selectedCount}/{project.allowedSelections})</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Sticky Selection Counter Bar (Crucial for mobile and desktop proofing UX) */}
      <div className="sticky top-0 z-30 bg-[#0a0b10]/95 backdrop-blur-xl border-b border-neutral-800/80 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Counter & Progress */}
            <div className="flex items-center gap-4 flex-1">
              <div className="shrink-0">
                <span className="text-[11px] text-neutral-400 block font-medium">Kuota Pilihan</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-xl sm:text-2xl font-bold font-mono text-amber-400">
                    {selectedCount}
                  </span>
                  <span className="text-xs text-neutral-400 font-mono">
                    / {project.allowedSelections} foto
                  </span>
                </div>
              </div>

              {/* Visual Progress Bar */}
              <div className="flex-1 max-w-xs">
                <div className="w-full bg-neutral-900 h-2.5 rounded-full overflow-hidden border border-neutral-800/80">
                  <div
                    className={`h-full transition-all duration-300 ${
                      selectedCount > project.allowedSelections
                        ? 'bg-rose-500'
                        : selectedCount === project.allowedSelections
                        ? 'bg-emerald-400'
                        : 'bg-gradient-to-r from-amber-500 to-amber-300'
                    }`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-neutral-400 mt-1 font-mono">
                  <span>{progressPercent}% Terisi</span>
                  <span>
                    {selectedCount > project.allowedSelections
                      ? `Kelebihan ${selectedCount - project.allowedSelections} foto`
                      : selectedCount === project.allowedSelections
                      ? 'Kuota Pas'
                      : `Sisa ${project.allowedSelections - selectedCount} foto`}
                  </span>
                </div>
              </div>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs">
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
                  filterType === 'all'
                    ? 'bg-amber-400 text-neutral-950 font-bold'
                    : 'bg-[#111218] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
                }`}
              >
                Semua ({photos.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterType('selected')}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  filterType === 'selected'
                    ? 'bg-amber-400 text-neutral-950 font-bold'
                    : 'bg-[#111218] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
                }`}
              >
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Dipilih ({selectedCount})</span>
              </button>
              <button
                type="button"
                onClick={() => setFilterType('favorites')}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  filterType === 'favorites'
                    ? 'bg-rose-500 text-white font-bold'
                    : 'bg-[#111218] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
                }`}
              >
                <Heart className="w-3.5 h-3.5 fill-current" />
                <span>Favorit ({favoriteCount})</span>
              </button>
              <button
                type="button"
                onClick={() => setFilterType('unselected')}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
                  filterType === 'unselected'
                    ? 'bg-neutral-800 text-white font-bold'
                    : 'bg-[#111218] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
                }`}
              >
                Belum Dipilih ({photos.length - selectedCount})
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-toolbar: Search & Category filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari file foto (misal: 0102)..."
              className="w-full bg-[#0e0f14] border border-neutral-800/90 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-neutral-400 absolute right-3 top-1/2 -translate-y-1/2 hover:text-white"
              >
                Reset
              </button>
            )}
          </div>

          {/* Categories Pill List */}
          {categories.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs py-1">
              <span className="text-neutral-500 text-xs mr-1 hidden md:inline">Kategori:</span>
              <button
                type="button"
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-1.5 rounded-xl capitalize transition-colors ${
                  selectedCategory === 'all'
                    ? 'bg-amber-400 text-neutral-950 font-bold'
                    : 'bg-[#111218] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
                }`}
              >
                Semua
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl capitalize transition-colors ${
                    selectedCategory === cat
                      ? 'bg-amber-400 text-neutral-950 font-bold'
                      : 'bg-[#111218] text-neutral-400 hover:text-neutral-200 border border-neutral-800/80'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Locked status banner if submitted */}
        {isLocked && (
          <div className="mt-4 p-4 rounded-2xl bg-emerald-950/30 border border-emerald-800/40 flex items-center justify-between gap-3 text-xs sm:text-sm text-emerald-200">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <strong>Pilihan foto Anda telah berhasil dikunci & disubmit final.</strong>
                <p className="text-emerald-300/80 text-xs mt-0.5">
                  Admin fotografer sedang mempersiapkan proses editing sesuai daftar pilihan Anda.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Photo Gallery Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6">
        {filteredPhotos.length === 0 ? (
          <div className="text-center py-20 bg-[#0e0f14]/60 rounded-3xl border border-neutral-800/70 p-6">
            <Filter className="w-12 h-12 mx-auto text-neutral-600 mb-3" />
            <h3 className="text-base font-semibold text-neutral-300">Tidak Ada Foto Ditemukan</h3>
            <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
              Tidak ada foto yang cocok dengan filter aktif saat ini. Coba pilih tab lain atau bersihkan pencarian.
            </p>
            <button
              onClick={() => {
                setFilterType('all');
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 rounded-xl transition-colors"
            >
              Reset Semua Filter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {filteredPhotos.map((photo) => {
              const fullIndex = photos.findIndex((p) => p.id === photo.id);
              return (
                <PhotoCard
                  key={photo.id}
                  photo={photo}
                  watermarkConfig={project.watermark}
                  vendorName={vendor.name}
                  isLocked={isLocked}
                  onToggleSelect={() => onToggleSelect(photo.id)}
                  onToggleFavorite={() => onToggleFavorite(photo.id)}
                  onOpenLightbox={() => setLightboxIndex(fullIndex)}
                  onAddNote={() => handleOpenNoteEditor(photo)}
                />
              );
            })}
          </div>
        )}
      </main>

      {/* Lightbox Viewer */}
      {lightboxIndex !== null && (
        <LightboxModal
          photos={photos}
          currentIndex={lightboxIndex}
          isOpen={lightboxIndex !== null}
          watermarkConfig={project.watermark}
          vendorName={vendor.name}
          isLocked={isLocked}
          quotaMax={project.allowedSelections}
          quotaSelected={selectedCount}
          onClose={() => setLightboxIndex(null)}
          onNavigate={(newIdx) => setLightboxIndex(newIdx)}
          onToggleSelect={(id) => onToggleSelect(id)}
          onToggleFavorite={(id) => onToggleFavorite(id)}
          onUpdateNote={(id, note) => onUpdateNote(id, note)}
        />
      )}

      {/* Note Edit Modal Dialog */}
      {activeNotePhotoId && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e0f14] border border-neutral-800/90 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 stroke-[2.2]" />
              <span>Catatan Khusus Editing</span>
            </h3>
            <p className="text-xs text-neutral-400">
              Tuliskan instruksi atau revisi khusus untuk foto ini agar tim editor paham preferensi Anda.
            </p>
            <textarea
              value={tempNoteText}
              onChange={(e) => setTempNoteText(e.target.value)}
              placeholder="Contoh: Tolong hilangkan orang di background sebelah kiri, wajah jangan terlalu putih..."
              rows={3}
              className="w-full bg-[#14151c] border border-neutral-800 rounded-xl p-3 text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors"
              autoFocus
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setActiveNotePhotoId(null)}
                className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-300 rounded-xl transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveNote}
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-xs font-bold text-neutral-950 rounded-xl transition-all shadow-md"
              >
                Simpan Catatan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Submit Selection Dialog */}
      <SubmitSelectionModal
        isOpen={isSubmitModalOpen}
        project={project}
        photos={photos}
        vendorPhone={vendor.phone}
        vendorName={vendor.name}
        onClose={() => setIsSubmitModalOpen(false)}
        onSubmit={(notes) => {
          onSubmitFinal(notes);
          setIsSubmitModalOpen(false);
        }}
      />
    </div>
  );
};

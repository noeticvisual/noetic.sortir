import React, { useState } from 'react';
import { Project } from '../../types';
import { Lock, ArrowRight, ShieldCheck, KeyRound } from 'lucide-react';

interface PinGateViewProps {
  project: Project;
  onUnlock: () => void;
  vendorName: string;
}

export const PinGateView: React.FC<PinGateViewProps> = ({
  project,
  onUnlock,
  vendorName,
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!project.pinCode || pin.trim() === project.pinCode.trim()) {
      onUnlock();
    } else {
      setError('PIN akses tidak sesuai. Silakan cek kembali pesan dari vendor.');
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-[#0e0f14] border border-neutral-800/90 rounded-3xl p-6 sm:p-8 shadow-2xl text-center backdrop-blur-xl">
        {/* Cover photo blur thumbnail */}
        {project.coverPhotoUrl && (
          <div className="relative h-32 w-full rounded-2xl overflow-hidden mb-6 border border-neutral-800">
            <img 
              src={project.coverPhotoUrl} 
              alt={project.title} 
              className="w-full h-full object-cover blur-xs brightness-40" 
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="p-3 bg-black/70 backdrop-blur-md rounded-2xl text-amber-400 border border-amber-500/30 shadow-lg">
                <Lock className="w-6 h-6 stroke-[2.2]" />
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2 mb-6">
          <span className="text-[10px] font-bold text-amber-400/90 uppercase tracking-[0.2em] bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20 font-mono">
            Galeri Terproteksi PIN
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-display">
            {project.title}
          </h1>
          <p className="text-xs text-neutral-400">
            Sesi Foto: <strong className="text-neutral-200">{project.clientName}</strong> • {vendorName}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-neutral-400 mb-2 font-medium">
              Masukkan 4-Digit PIN Akses Klien
            </label>
            <div className="relative max-w-xs mx-auto">
              <KeyRound className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500" />
              <input
                type="password"
                maxLength={6}
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  setError('');
                }}
                placeholder="••••"
                className="w-full bg-[#14151c] border border-neutral-800 rounded-xl py-3 pl-11 pr-4 text-center font-mono text-xl tracking-[0.3em] text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all"
                autoFocus
              />
            </div>
            {error && (
              <p className="text-xs text-rose-400 mt-2 font-medium">
                {error}
              </p>
            )}
          </div>

          <button
            type="submit"
            className="w-full max-w-xs mx-auto bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-neutral-950 font-bold py-3 px-6 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 transition-all active:scale-95 text-xs"
          >
            <span>Buka Galeri Foto</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </form>

        {/* Demo Hint */}
        {project.pinCode && (
          <div className="mt-6 pt-4 border-t border-neutral-800/80 text-[11px] text-neutral-500">
            <span>Demo PIN: </span>
            <span className="font-mono text-amber-400 font-bold bg-[#14151c] px-2.5 py-0.5 rounded border border-neutral-800">
              {project.pinCode}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Project, PhotoItem, ActivityLog, VendorProfile } from './types';
import {
  getProjects,
  getPhotos,
  getLogs,
  getVendorProfile,
  subscribeToStore,
  createProject,
  addPhotosToProject,
  deletePhoto,
  togglePhotoSelection,
  togglePhotoFavorite,
  updatePhotoNote,
  togglePhotoEdited,
  submitFinalClientSelection,
  unlockClientSelection,
  updateProject,
  deleteProject,
  resetStoreToSample,
} from './services/storageService';
import { Navbar } from './components/Navbar';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminSelectionReview } from './components/admin/AdminSelectionReview';
import { AdminLoginView } from './components/admin/AdminLoginView';
import { CreateProjectModal } from './components/admin/CreateProjectModal';
import { PhotoUploadModal } from './components/admin/PhotoUploadModal';
import { ShareLinkModal } from './components/admin/ShareLinkModal';
import { CloudArchitectureGuide } from './components/admin/CloudArchitectureGuide';
import { ClientGalleryView } from './components/client/ClientGalleryView';

export default function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [photos, setPhotos] = useState<PhotoItem[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [vendor, setVendor] = useState<VendorProfile>(getVendorProfile());

  // Authentication state for Admin
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('noetic_admin_auth') === 'true';
  });

  // Navigation / View state
  const [currentMode, setCurrentMode] = useState<'admin' | 'client'>('admin');
  const [isDirectClientLink, setIsDirectClientLink] = useState<boolean>(false);
  const [activeProjectId, setActiveProjectId] = useState<string>('');
  const [reviewProjectId, setReviewProjectId] = useState<string | null>(null);
  const [showCloudGuide, setShowCloudGuide] = useState(false);

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [uploadProjectTarget, setUploadProjectTarget] = useState<Project | null>(null);
  const [shareProjectTarget, setShareProjectTarget] = useState<Project | null>(null);

  // Initialize and subscribe
  useEffect(() => {
    const refreshState = () => {
      const p = getProjects();
      const ph = getPhotos();
      const l = getLogs();
      const v = getVendorProfile();
      setProjects(p);
      setPhotos(ph);
      setLogs(l);
      setVendor(v);

      // Check URL query parameters for direct client links (e.g. ?project=sesha-rama-w88k or ?token=sesha-rama-w88k)
      const params = new URLSearchParams(window.location.search);
      const projectToken = params.get('project') || params.get('token');
      if (projectToken) {
        const found = p.find((proj) => proj.shareToken === projectToken || proj.id === projectToken);
        if (found) {
          setActiveProjectId(found.id);
          setCurrentMode('client');
          setIsDirectClientLink(true);
        }
      } else if (!activeProjectId && p.length > 0) {
        setActiveProjectId(p[0].id);
      }
    };

    refreshState();
    const unsubscribe = subscribeToStore(refreshState);
    return () => unsubscribe();
  }, []);

  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0];
  const reviewingProject = projects.find((p) => p.id === reviewProjectId);

  const handleAdminLogin = () => {
    setIsAdminAuthenticated(true);
    sessionStorage.setItem('noetic_admin_auth', 'true');
    setCurrentMode('admin');
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem('noetic_admin_auth');
    setCurrentMode('admin');
    setReviewProjectId(null);
    setShowCloudGuide(false);
  };

  const handleSwitchToClientPreview = (projectId?: string) => {
    if (projectId) {
      setActiveProjectId(projectId);
    }
    setCurrentMode('client');
    setIsDirectClientLink(false);
  };

  const handleReturnToAdmin = () => {
    if (!isAdminAuthenticated) {
      setCurrentMode('admin');
      return;
    }
    setCurrentMode('admin');
  };

  // If in admin mode and NOT authenticated, show the dedicated Admin Login Screen
  if (currentMode === 'admin' && !isAdminAuthenticated) {
    return (
      <AdminLoginView
        vendor={vendor}
        onLoginSuccess={handleAdminLogin}
        onSwitchToClientDemo={() => {
          if (projects.length > 0) {
            setActiveProjectId(projects[0].id);
          }
          setCurrentMode('client');
          setIsDirectClientLink(true);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#07080a] text-neutral-100 flex flex-col font-sans selection:bg-amber-400 selection:text-neutral-950">
      {/* Top Navigation */}
      <Navbar
        currentMode={currentMode}
        activeProject={activeProject}
        vendor={vendor}
        isAdminAuthenticated={isAdminAuthenticated}
        isDirectClientLink={isDirectClientLink}
        onLogoutAdmin={handleAdminLogout}
        onReturnToAdmin={handleReturnToAdmin}
      />

      {/* Main Content Area */}
      <div className="flex-1">
        {currentMode === 'client' && activeProject ? (
          /* Client Proofing Portal - Client can only select/review photos, cannot access admin */
          <ClientGalleryView
            key={activeProject.id}
            project={activeProject}
            photos={photos.filter((p) => p.projectId === activeProject.id)}
            vendor={vendor}
            onToggleSelect={(photoId) => {
              const res = togglePhotoSelection(photoId, activeProject.id);
              if (!res.success && res.message) {
                alert(res.message);
              }
            }}
            onToggleFavorite={(photoId) => togglePhotoFavorite(photoId)}
            onUpdateNote={(photoId, note) => updatePhotoNote(photoId, note)}
            onSubmitFinal={(notes) => {
              submitFinalClientSelection(activeProject.id, notes);
            }}
          />
        ) : reviewingProject ? (
          /* Admin Selection Review View */
          <AdminSelectionReview
            project={reviewingProject}
            photos={photos.filter((p) => p.projectId === reviewingProject.id)}
            logs={logs.filter((l) => l.projectId === reviewingProject.id)}
            onBack={() => setReviewProjectId(null)}
            onTogglePhotoEdited={(photoId) => togglePhotoEdited(photoId)}
            onMarkProjectCompleted={() => {
              updateProject(reviewingProject.id, {
                status: 'completed',
                completedAt: new Date().toISOString(),
              });
            }}
            onUnlockSelection={() => {
              unlockClientSelection(reviewingProject.id);
            }}
          />
        ) : showCloudGuide ? (
          /* Cloud Architecture Guide */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
            <div className="flex items-center justify-between mb-6">
              <button
                type="button"
                onClick={() => setShowCloudGuide(false)}
                className="px-4 py-2 bg-[#12131a] hover:bg-[#1a1c26] text-neutral-200 border border-neutral-800 text-xs font-semibold rounded-xl transition-colors"
              >
                &larr; Kembali ke Dashboard
              </button>
            </div>
            <CloudArchitectureGuide />
          </div>
        ) : (
          /* Admin Dashboard */
          <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
            <AdminDashboard
              projects={projects}
              photos={photos}
              vendor={vendor}
              onSelectProjectForReview={(proj) => setReviewProjectId(proj.id)}
              onOpenUploadModal={(proj) => setUploadProjectTarget(proj)}
              onOpenShareModal={(proj) => setShareProjectTarget(proj)}
              onOpenCreateProjectModal={() => setIsCreateModalOpen(true)}
              onOpenClientView={(proj) => handleSwitchToClientPreview(proj.id)}
              onOpenCloudGuide={() => setShowCloudGuide(true)}
              onDeleteProject={(id) => deleteProject(id)}
              onResetDemoData={() => resetStoreToSample()}
            />
          </main>
        )}
      </div>

      {/* Modals */}
      {isCreateModalOpen && (
        <CreateProjectModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          onCreate={(data) => {
            const created = createProject(data);
            setActiveProjectId(created.id);
            setUploadProjectTarget(created);
          }}
        />
      )}

      {uploadProjectTarget && (
        <PhotoUploadModal
          isOpen={!!uploadProjectTarget}
          project={uploadProjectTarget}
          onClose={() => setUploadProjectTarget(null)}
          onUploadComplete={(newPhotos) => {
            addPhotosToProject(uploadProjectTarget.id, newPhotos);
          }}
        />
      )}

      {shareProjectTarget && (
        <ShareLinkModal
          isOpen={!!shareProjectTarget}
          project={shareProjectTarget}
          vendor={vendor}
          onClose={() => setShareProjectTarget(null)}
          onOpenClientView={() => handleSwitchToClientPreview(shareProjectTarget.id)}
        />
      )}
    </div>
  );
}

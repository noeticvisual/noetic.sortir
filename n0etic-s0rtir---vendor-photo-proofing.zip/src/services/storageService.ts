import { Project, PhotoItem, ActivityLog, VendorProfile, WatermarkConfig } from '../types';
import { sampleProjects, samplePhotos, sampleActivityLogs, initialVendorProfile } from '../data/mockData';
import JSZip from 'jszip';

const STORAGE_KEYS = {
  PROJECTS: 'sortirfoto_projects_v1',
  PHOTOS: 'sortirfoto_photos_v1',
  LOGS: 'sortirfoto_logs_v1',
  VENDOR: 'sortirfoto_vendor_v1',
};

// Event emitter for reactive state updates across components
type Listener = () => void;
const listeners: Set<Listener> = new Set();

export function subscribeToStore(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function notifyListeners() {
  listeners.forEach((l) => {
    try {
      l();
    } catch (e) {
      console.error('Store listener error:', e);
    }
  });
}

// Initializers
export function getProjects(): Project[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROJECTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(sampleProjects));
      return sampleProjects;
    }
    return JSON.parse(raw);
  } catch {
    return sampleProjects;
  }
}

export function saveProjects(projects: Project[]) {
  localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  notifyListeners();
}

export function getPhotos(projectId?: string): PhotoItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PHOTOS);
    let allPhotos: PhotoItem[] = [];
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.PHOTOS, JSON.stringify(samplePhotos));
      allPhotos = samplePhotos;
    } else {
      allPhotos = JSON.parse(raw);
    }
    if (projectId) {
      return allPhotos.filter((p) => p.projectId === projectId);
    }
    return allPhotos;
  } catch {
    return projectId ? samplePhotos.filter((p) => p.projectId === projectId) : samplePhotos;
  }
}

export function savePhotos(photos: PhotoItem[]) {
  localStorage.setItem(STORAGE_KEYS.PHOTOS, JSON.stringify(photos));
  notifyListeners();
}

export function getLogs(projectId?: string): ActivityLog[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LOGS);
    let allLogs: ActivityLog[] = [];
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(sampleActivityLogs));
      allLogs = sampleActivityLogs;
    } else {
      allLogs = JSON.parse(raw);
    }
    if (projectId) {
      return allLogs.filter((l) => l.projectId === projectId);
    }
    return allLogs;
  } catch {
    return sampleActivityLogs;
  }
}

export function addLog(log: Omit<ActivityLog, 'id' | 'timestamp'>) {
  const logs = getLogs();
  const newLog: ActivityLog = {
    ...log,
    id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    timestamp: new Date().toISOString(),
  };
  localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify([newLog, ...logs]));
  notifyListeners();
}

export function getVendorProfile(): VendorProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.VENDOR);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.VENDOR, JSON.stringify(initialVendorProfile));
      return initialVendorProfile;
    }
    return JSON.parse(raw);
  } catch {
    return initialVendorProfile;
  }
}

export function saveVendorProfile(profile: VendorProfile) {
  localStorage.setItem(STORAGE_KEYS.VENDOR, JSON.stringify(profile));
  notifyListeners();
}

// Project Operations
export function createProject(data: {
  title: string;
  clientName: string;
  clientEmail?: string;
  clientPhone?: string;
  sessionType: Project['sessionType'];
  sessionDate: string;
  allowedSelections: number;
  requiresPin: boolean;
  pinCode?: string;
  expiresDays?: number;
  watermarkText?: string;
}): Project {
  const projects = getProjects();
  const token = (
    data.clientName.toLowerCase().replace(/[^a-z0-9]/g, '-') +
    '-' +
    Math.random().toString(36).substring(2, 6)
  ).replace(/--+/g, '-');

  const expiresAt = data.expiresDays 
    ? new Date(Date.now() + data.expiresDays * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    : undefined;

  const newProject: Project = {
    id: 'proj-' + Date.now(),
    title: data.title,
    clientName: data.clientName,
    clientEmail: data.clientEmail,
    clientPhone: data.clientPhone,
    sessionType: data.sessionType,
    sessionDate: data.sessionDate,
    createdAt: new Date().toISOString(),
    status: 'pending_upload',
    allowedSelections: data.allowedSelections || 20,
    currentSelectionsCount: 0,
    shareToken: token,
    requiresPin: data.requiresPin,
    pinCode: data.pinCode,
    expiresAt,
    disableRightClick: true,
    watermark: {
      text: data.watermarkText || 'LUMINA STORY • PROOF ONLY',
      opacity: 0.45,
      position: 'tile',
      fontSize: 22,
      color: '#ffffff',
    },
  };

  saveProjects([newProject, ...projects]);
  addLog({
    projectId: newProject.id,
    action: 'Project Dibuat',
    description: `Project "${newProject.title}" berhasil dibuat untuk klien ${newProject.clientName}.`,
    actor: 'admin',
  });

  return newProject;
}

export function updateProject(id: string, updates: Partial<Project>) {
  const projects = getProjects();
  const index = projects.findIndex((p) => p.id === id);
  if (index !== -1) {
    projects[index] = { ...projects[index], ...updates };
    saveProjects(projects);
  }
}

export function deleteProject(id: string) {
  const projects = getProjects().filter((p) => p.id !== id);
  const photos = getPhotos().filter((p) => p.projectId !== id);
  const logs = getLogs().filter((p) => p.projectId !== id);
  
  saveProjects(projects);
  savePhotos(photos);
  localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  notifyListeners();
}

// Photo Operations
export function addPhotosToProject(projectId: string, newPhotos: Omit<PhotoItem, 'id' | 'projectId' | 'uploadedAt' | 'isSelected' | 'isFavorite'>[]) {
  const allPhotos = getPhotos();
  const createdPhotos: PhotoItem[] = newPhotos.map((p, idx) => ({
    ...p,
    id: 'ph-' + Date.now() + '-' + idx + '-' + Math.random().toString(36).substring(2, 6),
    projectId,
    uploadedAt: new Date().toISOString(),
    isSelected: false,
    isFavorite: false,
  }));

  const updatedAll = [...createdPhotos, ...allPhotos];
  savePhotos(updatedAll);

  // Update project status if was pending_upload
  const projects = getProjects();
  const proj = projects.find((p) => p.id === projectId);
  if (proj) {
    const updates: Partial<Project> = {};
    if (proj.status === 'pending_upload') {
      updates.status = 'waiting_selection';
    }
    if (!proj.coverPhotoUrl && createdPhotos.length > 0) {
      updates.coverPhotoUrl = createdPhotos[0].thumbnailUrl;
    }
    if (Object.keys(updates).length > 0) {
      updateProject(projectId, updates);
    }
  }

  addLog({
    projectId,
    action: 'Upload Foto Massal',
    description: `Berhasil mengunggah ${newPhotos.length} foto baru ke dalam galeri.`,
    actor: 'admin',
  });

  return createdPhotos;
}

export function deletePhoto(photoId: string) {
  const photos = getPhotos();
  const photo = photos.find((p) => p.id === photoId);
  const filtered = photos.filter((p) => p.id !== photoId);
  savePhotos(filtered);

  if (photo && photo.projectId) {
    recalcProjectSelections(photo.projectId);
  }
}

export function togglePhotoSelection(photoId: string, projectId: string): { success: boolean; message?: string } {
  const allPhotos = getPhotos();
  const photo = allPhotos.find((p) => p.id === photoId);
  const projects = getProjects();
  const project = projects.find((p) => p.id === projectId);

  if (!photo || !project) {
    return { success: false, message: 'Foto atau project tidak ditemukan' };
  }

  if (project.status === 'submitted' || project.status === 'completed') {
    return { success: false, message: 'Seleksi telah dikunci/disubmit final.' };
  }

  const currentSelectedInProj = allPhotos.filter((p) => p.projectId === projectId && p.isSelected).length;

  if (!photo.isSelected && currentSelectedInProj >= project.allowedSelections) {
    return {
      success: false,
      message: `Kuota seleksi paket (${project.allowedSelections} foto) sudah tercapai. Batalkan pilihan foto lain terlebih dahulu untuk memilih foto ini.`,
    };
  }

  photo.isSelected = !photo.isSelected;
  photo.selectedAt = photo.isSelected ? new Date().toISOString() : undefined;
  savePhotos(allPhotos);

  recalcProjectSelections(projectId);
  return { success: true };
}

export function togglePhotoFavorite(photoId: string) {
  const allPhotos = getPhotos();
  const photo = allPhotos.find((p) => p.id === photoId);
  if (photo) {
    photo.isFavorite = !photo.isFavorite;
    savePhotos(allPhotos);
  }
}

export function updatePhotoNote(photoId: string, note: string) {
  const allPhotos = getPhotos();
  const photo = allPhotos.find((p) => p.id === photoId);
  if (photo) {
    photo.clientNote = note;
    savePhotos(allPhotos);
  }
}

export function togglePhotoEdited(photoId: string) {
  const allPhotos = getPhotos();
  const photo = allPhotos.find((p) => p.id === photoId);
  if (photo) {
    photo.isEdited = !photo.isEdited;
    savePhotos(allPhotos);
  }
}

export function submitFinalClientSelection(projectId: string, clientNotes?: string): { success: boolean; message: string } {
  const projects = getProjects();
  const project = projects.find((p) => p.id === projectId);
  if (!project) return { success: false, message: 'Project tidak ditemukan' };

  const photos = getPhotos(projectId);
  const selectedCount = photos.filter((p) => p.isSelected).length;

  if (selectedCount === 0) {
    return { success: false, message: 'Pilih minimal 1 foto sebelum submit.' };
  }

  updateProject(projectId, {
    status: 'submitted',
    submittedAt: new Date().toISOString(),
    finalClientNotes: clientNotes,
    currentSelectionsCount: selectedCount,
  });

  addLog({
    projectId,
    action: 'Pilihan Final Disubmit Klien',
    description: `Klien menyelesaikan seleksi (${selectedCount} dari ${project.allowedSelections} foto).`,
    actor: 'client',
  });

  return {
    success: true,
    message: `Berhasil submit ${selectedCount} foto pilihan! Fotografer akan segera memproses editing.`,
  };
}

export function unlockClientSelection(projectId: string) {
  updateProject(projectId, {
    status: 'waiting_selection',
  });
  addLog({
    projectId,
    action: 'Seleksi Dibuka Kembali (Revisi)',
    description: 'Admin membuka kembali akses seleksi agar klien bisa merevisi pilihan.',
    actor: 'admin',
  });
}

function recalcProjectSelections(projectId: string) {
  const allPhotos = getPhotos(projectId);
  const count = allPhotos.filter((p) => p.isSelected).length;
  updateProject(projectId, { currentSelectionsCount: count });
}

// Lightroom Filename Formatter
export function getLightroomFilterString(photos: PhotoItem[]): string {
  const selected = photos.filter((p) => p.isSelected);
  // Removes extension e.g. "SR_WED_0102" or keeps full file name
  return selected.map((p) => p.fileName).join(', ');
}

// Bulk ZIP Downloader for Admin
export async function downloadSelectionsAsZip(project: Project, photos: PhotoItem[]): Promise<void> {
  const selectedPhotos = photos.filter((p) => p.isSelected);
  if (selectedPhotos.length === 0) {
    alert('Tidak ada foto yang dipilih untuk diunduh.');
    return;
  }

  const zip = new JSZip();
  const folder = zip.folder(`Seleksi_${project.clientName.replace(/\s+/g, '_')}`);

  // Create instructions and manifest text
  let manifestText = `=====================================================\n`;
  manifestText += `DAFTAR FOTO PILIHAN KLIEN - ${project.title.toUpperCase()}\n`;
  manifestText += `=====================================================\n`;
  manifestText += `Klien        : ${project.clientName}\n`;
  manifestText += `Tanggal Sesi : ${project.sessionDate}\n`;
  manifestText += `Total Pilihan: ${selectedPhotos.length} / ${project.allowedSelections} foto\n`;
  manifestText += `Disubmit Pada: ${project.submittedAt ? new Date(project.submittedAt).toLocaleString('id-ID') : 'Belum Submit Final'}\n`;
  if (project.finalClientNotes) {
    manifestText += `Catatan Klien: "${project.finalClientNotes}"\n`;
  }
  manifestText += `\nLIGHTROOM / CAPTURE ONE SEARCH FILTER STRING:\n`;
  manifestText += `${selectedPhotos.map((p) => p.fileName).join(', ')}\n\n`;
  manifestText += `RINCIAN FOTO & CATATAN KHUSUS TIAP FILE:\n`;
  manifestText += `-----------------------------------------------------\n`;

  selectedPhotos.forEach((photo, idx) => {
    manifestText += `${idx + 1}. [${photo.fileName}] - Kategori: ${photo.category || 'General'}\n`;
    if (photo.clientNote) {
      manifestText += `   Catatan Edit Klien: "${photo.clientNote}"\n`;
    }
    manifestText += `\n`;
  });

  folder?.file('INSTRUKSI_EDITING_KLIEN.txt', manifestText);
  folder?.file('LIGHTROOM_FILTER_STRING.txt', selectedPhotos.map((p) => p.fileName).join(', '));

  // For client-side demo images, we fetch and embed blobs into the zip
  const fetchPromises = selectedPhotos.map(async (photo) => {
    try {
      // Use originalUrl or previewUrl
      const response = await fetch(photo.originalUrl);
      const blob = await response.blob();
      folder?.file(photo.fileName, blob);
    } catch {
      // If CORS or local blob fails, write placeholder file with info
      folder?.file(
        photo.fileName + '.info.txt',
        `File: ${photo.fileName}\nCatatan: ${photo.clientNote || '-'}\nURL: ${photo.originalUrl}`
      );
    }
  });

  await Promise.all(fetchPromises);

  const content = await zip.generateAsync({ type: 'blob' });
  const downloadUrl = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = downloadUrl;
  a.download = `Foto_Pilihan_${project.clientName.replace(/\s+/g, '_')}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(downloadUrl);

  addLog({
    projectId: project.id,
    action: 'Unduh ZIP Pilihan',
    description: `Admin mengunduh paket ZIP berisi ${selectedPhotos.length} foto pilihan dan file instruksi Lightroom.`,
    actor: 'admin',
  });
}

// Reset data to factory demo
export function resetStoreToSample() {
  localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(sampleProjects));
  localStorage.setItem(STORAGE_KEYS.PHOTOS, JSON.stringify(samplePhotos));
  localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(sampleActivityLogs));
  localStorage.setItem(STORAGE_KEYS.VENDOR, JSON.stringify(initialVendorProfile));
  notifyListeners();
}
